package br.com.cpsinformatica.relatoriosgerenciais.Networking;

import java.util.HashMap;
import java.util.Map;
import javax.annotation.Generated;

@Generated("org.jsonschema2pojo")
public class CREDITO {

private br.com.cpsinformatica.relatoriosgerenciais.Networking.MASTERCARD MASTERCARD;
private br.com.cpsinformatica.relatoriosgerenciais.Networking.VISA VISA;
private br.com.cpsinformatica.relatoriosgerenciais.Networking.TOTAL TOTAL;
private Map<String, Object> additionalProperties = new HashMap<String, Object>();

/**
* 
* @return
* The MASTERCARD
*/
public br.com.cpsinformatica.relatoriosgerenciais.Networking.MASTERCARD getMASTERCARD() {
return MASTERCARD;
}

/**
* 
* @param MASTERCARD
* The MASTERCARD
*/
public void setMASTERCARD(br.com.cpsinformatica.relatoriosgerenciais.Networking.MASTERCARD MASTERCARD) {
this.MASTERCARD = MASTERCARD;
}

/**
* 
* @return
* The VISA
*/
public br.com.cpsinformatica.relatoriosgerenciais.Networking.VISA getVISA() {
return VISA;
}

/**
* 
* @param VISA
* The VISA
*/
public void setVISA(br.com.cpsinformatica.relatoriosgerenciais.Networking.VISA VISA) {
this.VISA = VISA;
}

/**
* 
* @return
* The TOTAL
*/
public br.com.cpsinformatica.relatoriosgerenciais.Networking.TOTAL getTOTAL() {
return TOTAL;
}

/**
* 
* @param TOTAL
* The TOTAL
*/
public void setTOTAL(br.com.cpsinformatica.relatoriosgerenciais.Networking.TOTAL TOTAL) {
this.TOTAL = TOTAL;
}

public Map<String, Object> getAdditionalProperties() {
return this.additionalProperties;
}

public void setAdditionalProperty(String name, Object value) {
this.additionalProperties.put(name, value);
}

}
-----------------------------------br.com.cpsinformatica.relatoriosgerenciais.asynctasks.DEBITO.java-----------------------------------

package br.com.cpsinformatica.relatoriosgerenciais.asynctasks;

import java.util.HashMap;
import java.util.Map;
import javax.annotation.Generated;

@Generated("org.jsonschema2pojo")
public class DEBITO {

private MASTERCARD_ MASTERCARD;
private VISA_ VISA;
private TOTAL_ TOTAL;
private Map<String, Object> additionalProperties = new HashMap<String, Object>();

/**
* 
* @return
* The MASTERCARD
*/
public MASTERCARD_ getMASTERCARD() {
return MASTERCARD;
}

/**
* 
* @param MASTERCARD
* The MASTERCARD
*/
public void setMASTERCARD(MASTERCARD_ MASTERCARD) {
this.MASTERCARD = MASTERCARD;
}

/**
* 
* @return
* The VISA
*/
public VISA_ getVISA() {
return VISA;
}

/**
* 
* @param VISA
* The VISA
*/
public void setVISA(VISA_ VISA) {
this.VISA = VISA;
}

/**
* 
* @return
* The TOTAL
*/
public TOTAL_ getTOTAL() {
return TOTAL;
}

/**
* 
* @param TOTAL
* The TOTAL
*/
public void setTOTAL(TOTAL_ TOTAL) {
this.TOTAL = TOTAL;
}

public Map<String, Object> getAdditionalProperties() {
return this.additionalProperties;
}

public void setAdditionalProperty(String name, Object value) {
this.additionalProperties.put(name, value);
}

}
-----------------------------------br.com.cpsinformatica.relatoriosgerenciais.asynctasks.FORMASPAGAMENTO.java-----------------------------------

package br.com.cpsinformatica.relatoriosgerenciais.asynctasks;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import javax.annotation.Generated;

@Generated("org.jsonschema2pojo")
public class FORMASPAGAMENTO {

private List<br.com.cpsinformatica.relatoriosgerenciais.Networking.CREDITO> CREDITO = new ArrayList<br.com.cpsinformatica.relatoriosgerenciais.Networking.CREDITO>();
private List<br.com.cpsinformatica.relatoriosgerenciais.Networking.DEBITO> DEBITO = new ArrayList<br.com.cpsinformatica.relatoriosgerenciais.Networking.DEBITO>();
private List<br.com.cpsinformatica.relatoriosgerenciais.Networking.VOUCHER> VOUCHER = new ArrayList<br.com.cpsinformatica.relatoriosgerenciais.Networking.VOUCHER>();
private Map<String, Object> additionalProperties = new HashMap<String, Object>();

/**
* 
* @return
* The CREDITO
*/
public List<br.com.cpsinformatica.relatoriosgerenciais.Networking.CREDITO> getCREDITO() {
return CREDITO;
}

/**
* 
* @param CREDITO
* The CREDITO
*/
public void setCREDITO(List<br.com.cpsinformatica.relatoriosgerenciais.Networking.CREDITO> CREDITO) {
this.CREDITO = CREDITO;
}

/**
* 
* @return
* The DEBITO
*/
public List<br.com.cpsinformatica.relatoriosgerenciais.Networking.DEBITO> getDEBITO() {
return DEBITO;
}

/**
* 
* @param DEBITO
* The DEBITO
*/
public void setDEBITO(List<br.com.cpsinformatica.relatoriosgerenciais.Networking.DEBITO> DEBITO) {
this.DEBITO = DEBITO;
}

/**
* 
* @return
* The VOUCHER
*/
public List<br.com.cpsinformatica.relatoriosgerenciais.Networking.VOUCHER> getVOUCHER() {
return VOUCHER;
}

/**
* 
* @param VOUCHER
* The VOUCHER
*/
public void setVOUCHER(List<br.com.cpsinformatica.relatoriosgerenciais.Networking.VOUCHER> VOUCHER) {
this.VOUCHER = VOUCHER;
}

public Map<String, Object> getAdditionalProperties() {
return this.additionalProperties;
}

public void setAdditionalProperty(String name, Object value) {
this.additionalProperties.put(name, value);
}

}
-----------------------------------br.com.cpsinformatica.relatoriosgerenciais.asynctasks.GsonParse.java-----------------------------------

package br.com.cpsinformatica.relatoriosgerenciais.asynctasks;

import java.util.HashMap;
import java.util.Map;
import javax.annotation.Generated;

@Generated("org.jsonschema2pojo")
public class GsonParse {

private Boolean status;
private String mensagem;
private String estabelecimento;
private String endereco;
private String cidade;
private String pos;
private String datetime;
private br.com.cpsinformatica.relatoriosgerenciais.Networking.FORMASPAGAMENTO FORMASPAGAMENTO;
private br.com.cpsinformatica.relatoriosgerenciais.Networking.TOTALGERAL TOTALGERAL;
private br.com.cpsinformatica.relatoriosgerenciais.Networking.RECORRENCIACLIENTE RECORRENCIACLIENTE;
private Map<String, Object> additionalProperties = new HashMap<String, Object>();

/**
* 
* @return
* The status
*/
public Boolean getStatus() {
return status;
}

/**
* 
* @param status
* The status
*/
public void setStatus(Boolean status) {
this.status = status;
}

/**
* 
* @return
* The mensagem
*/
public String getMensagem() {
return mensagem;
}

/**
* 
* @param mensagem
* The mensagem
*/
public void setMensagem(String mensagem) {
this.mensagem = mensagem;
}

/**
* 
* @return
* The estabelecimento
*/
public String getEstabelecimento() {
return estabelecimento;
}

/**
* 
* @param estabelecimento
* The estabelecimento
*/
public void setEstabelecimento(String estabelecimento) {
this.estabelecimento = estabelecimento;
}

/**
* 
* @return
* The endereco
*/
public String getEndereco() {
return endereco;
}

/**
* 
* @param endereco
* The endereco
*/
public void setEndereco(String endereco) {
this.endereco = endereco;
}

/**
* 
* @return
* The cidade
*/
public String getCidade() {
return cidade;
}

/**
* 
* @param cidade
* The cidade
*/
public void setCidade(String cidade) {
this.cidade = cidade;
}

/**
* 
* @return
* The pos
*/
public String getPos() {
return pos;
}

/**
* 
* @param pos
* The pos
*/
public void setPos(String pos) {
this.pos = pos;
}

/**
* 
* @return
* The datetime
*/
public String getDatetime() {
return datetime;
}

/**
* 
* @param datetime
* The datetime
*/
public void setDatetime(String datetime) {
this.datetime = datetime;
}

/**
* 
* @return
* The FORMASPAGAMENTO
*/
public br.com.cpsinformatica.relatoriosgerenciais.Networking.FORMASPAGAMENTO getFORMASPAGAMENTO() {
return FORMASPAGAMENTO;
}

/**
* 
* @param FORMASPAGAMENTO
* The FORMAS_PAGAMENTO
*/
public void setFORMASPAGAMENTO(br.com.cpsinformatica.relatoriosgerenciais.Networking.FORMASPAGAMENTO FORMASPAGAMENTO) {
this.FORMASPAGAMENTO = FORMASPAGAMENTO;
}

/**
* 
* @return
* The TOTALGERAL
*/
public br.com.cpsinformatica.relatoriosgerenciais.Networking.TOTALGERAL getTOTALGERAL() {
return TOTALGERAL;
}

/**
* 
* @param TOTALGERAL
* The TOTAL_GERAL
*/
public void setTOTALGERAL(br.com.cpsinformatica.relatoriosgerenciais.Networking.TOTALGERAL TOTALGERAL) {
this.TOTALGERAL = TOTALGERAL;
}

/**
* 
* @return
* The RECORRENCIACLIENTE
*/
public br.com.cpsinformatica.relatoriosgerenciais.Networking.RECORRENCIACLIENTE getRECORRENCIACLIENTE() {
return RECORRENCIACLIENTE;
}

/**
* 
* @param RECORRENCIACLIENTE
* The RECORRENCIA_CLIENTE
*/
public void setRECORRENCIACLIENTE(br.com.cpsinformatica.relatoriosgerenciais.Networking.RECORRENCIACLIENTE RECORRENCIACLIENTE) {
this.RECORRENCIACLIENTE = RECORRENCIACLIENTE;
}

public Map<String, Object> getAdditionalProperties() {
return this.additionalProperties;
}

public void setAdditionalProperty(String name, Object value) {
this.additionalProperties.put(name, value);
}

}
-----------------------------------br.com.cpsinformatica.relatoriosgerenciais.asynctasks.MASTERCARD.java-----------------------------------

package br.com.cpsinformatica.relatoriosgerenciais.asynctasks;

import java.util.HashMap;
import java.util.Map;
import javax.annotation.Generated;

@Generated("org.jsonschema2pojo")
public class MASTERCARD {

private String quantidade;
private String valor;
private Map<String, Object> additionalProperties = new HashMap<String, Object>();

/**
* 
* @return
* The quantidade
*/
public String getQuantidade() {
return quantidade;
}

/**
* 
* @param quantidade
* The quantidade
*/
public void setQuantidade(String quantidade) {
this.quantidade = quantidade;
}

/**
* 
* @return
* The valor
*/
public String getValor() {
return valor;
}

/**
* 
* @param valor
* The valor
*/
public void setValor(String valor) {
this.valor = valor;
}

public Map<String, Object> getAdditionalProperties() {
return this.additionalProperties;
}

public void setAdditionalProperty(String name, Object value) {
this.additionalProperties.put(name, value);
}

}
-----------------------------------br.com.cpsinformatica.relatoriosgerenciais.asynctasks.MASTERCARD_.java-----------------------------------

package br.com.cpsinformatica.relatoriosgerenciais.asynctasks;

import java.util.HashMap;
import java.util.Map;
import javax.annotation.Generated;

@Generated("org.jsonschema2pojo")
public class MASTERCARD_ {

private String quantidade;
private String valor;
private Map<String, Object> additionalProperties = new HashMap<String, Object>();

/**
* 
* @return
* The quantidade
*/
public String getQuantidade() {
return quantidade;
}

/**
* 
* @param quantidade
* The quantidade
*/
public void setQuantidade(String quantidade) {
this.quantidade = quantidade;
}

/**
* 
* @return
* The valor
*/
public String getValor() {
return valor;
}

/**
* 
* @param valor
* The valor
*/
public void setValor(String valor) {
this.valor = valor;
}

public Map<String, Object> getAdditionalProperties() {
return this.additionalProperties;
}

public void setAdditionalProperty(String name, Object value) {
this.additionalProperties.put(name, value);
}

}
-----------------------------------br.com.cpsinformatica.relatoriosgerenciais.asynctasks.MASTERCARD__.java-----------------------------------

package br.com.cpsinformatica.relatoriosgerenciais.asynctasks;

import java.util.HashMap;
import java.util.Map;
import javax.annotation.Generated;

@Generated("org.jsonschema2pojo")
public class MASTERCARD__ {

private String quantidade;
private String valor;
private Map<String, Object> additionalProperties = new HashMap<String, Object>();

/**
* 
* @return
* The quantidade
*/
public String getQuantidade() {
return quantidade;
}

/**
* 
* @param quantidade
* The quantidade
*/
public void setQuantidade(String quantidade) {
this.quantidade = quantidade;
}

/**
* 
* @return
* The valor
*/
public String getValor() {
return valor;
}

/**
* 
* @param valor
* The valor
*/
public void setValor(String valor) {
this.valor = valor;
}

public Map<String, Object> getAdditionalProperties() {
return this.additionalProperties;
}

public void setAdditionalProperty(String name, Object value) {
this.additionalProperties.put(name, value);
}

}
-----------------------------------br.com.cpsinformatica.relatoriosgerenciais.asynctasks.RECORRENCIACLIENTE.java-----------------------------------

package br.com.cpsinformatica.relatoriosgerenciais.asynctasks;

import java.util.HashMap;
import java.util.Map;
import javax.annotation.Generated;

@Generated("org.jsonschema2pojo")
public class RECORRENCIACLIENTE {

private String _1COMPRA;
private String _2COMPRAS;
private String _3COMPRASOUMAIS;
private Map<String, Object> additionalProperties = new HashMap<String, Object>();

/**
* 
* @return
* The _1COMPRA
*/
public String get1COMPRA() {
return _1COMPRA;
}

/**
* 
* @param _1COMPRA
* The 1_COMPRA
*/
public void set1COMPRA(String _1COMPRA) {
this._1COMPRA = _1COMPRA;
}

/**
* 
* @return
* The _2COMPRAS
*/
public String get2COMPRAS() {
return _2COMPRAS;
}

/**
* 
* @param _2COMPRAS
* The 2_COMPRAS
*/
public void set2COMPRAS(String _2COMPRAS) {
this._2COMPRAS = _2COMPRAS;
}

/**
* 
* @return
* The _3COMPRASOUMAIS
*/
public String get3COMPRASOUMAIS() {
return _3COMPRASOUMAIS;
}

/**
* 
* @param _3COMPRASOUMAIS
* The 3_COMPRAS_OU_MAIS
*/
public void set3COMPRASOUMAIS(String _3COMPRASOUMAIS) {
this._3COMPRASOUMAIS = _3COMPRASOUMAIS;
}

public Map<String, Object> getAdditionalProperties() {
return this.additionalProperties;
}

public void setAdditionalProperty(String name, Object value) {
this.additionalProperties.put(name, value);
}

}
-----------------------------------br.com.cpsinformatica.relatoriosgerenciais.asynctasks.TOTAL.java-----------------------------------

package br.com.cpsinformatica.relatoriosgerenciais.asynctasks;

import java.util.HashMap;
import java.util.Map;
import javax.annotation.Generated;

@Generated("org.jsonschema2pojo")
public class TOTAL {

private String quantidade;
private String total;
private Map<String, Object> additionalProperties = new HashMap<String, Object>();

/**
* 
* @return
* The quantidade
*/
public String getQuantidade() {
return quantidade;
}

/**
* 
* @param quantidade
* The quantidade
*/
public void setQuantidade(String quantidade) {
this.quantidade = quantidade;
}

/**
* 
* @return
* The total
*/
public String getTotal() {
return total;
}

/**
* 
* @param total
* The total
*/
public void setTotal(String total) {
this.total = total;
}

public Map<String, Object> getAdditionalProperties() {
return this.additionalProperties;
}

public void setAdditionalProperty(String name, Object value) {
this.additionalProperties.put(name, value);
}

}
-----------------------------------br.com.cpsinformatica.relatoriosgerenciais.asynctasks.TOTALGERAL.java-----------------------------------

package br.com.cpsinformatica.relatoriosgerenciais.asynctasks;

import java.util.HashMap;
import java.util.Map;
import javax.annotation.Generated;

@Generated("org.jsonschema2pojo")
public class TOTALGERAL {

private String quantidadeCancelamento;
private String totalCancelamentos;
private String quantidadeGeral;
private String totalGeral;
private Map<String, Object> additionalProperties = new HashMap<String, Object>();

/**
* 
* @return
* The quantidadeCancelamento
*/
public String getQuantidadeCancelamento() {
return quantidadeCancelamento;
}

/**
* 
* @param quantidadeCancelamento
* The quantidade_cancelamento
*/
public void setQuantidadeCancelamento(String quantidadeCancelamento) {
this.quantidadeCancelamento = quantidadeCancelamento;
}

/**
* 
* @return
* The totalCancelamentos
*/
public String getTotalCancelamentos() {
return totalCancelamentos;
}

/**
* 
* @param totalCancelamentos
* The total_cancelamentos
*/
public void setTotalCancelamentos(String totalCancelamentos) {
this.totalCancelamentos = totalCancelamentos;
}

/**
* 
* @return
* The quantidadeGeral
*/
public String getQuantidadeGeral() {
return quantidadeGeral;
}

/**
* 
* @param quantidadeGeral
* The quantidade_geral
*/
public void setQuantidadeGeral(String quantidadeGeral) {
this.quantidadeGeral = quantidadeGeral;
}

/**
* 
* @return
* The totalGeral
*/
public String getTotalGeral() {
return totalGeral;
}

/**
* 
* @param totalGeral
* The total_geral
*/
public void setTotalGeral(String totalGeral) {
this.totalGeral = totalGeral;
}

public Map<String, Object> getAdditionalProperties() {
return this.additionalProperties;
}

public void setAdditionalProperty(String name, Object value) {
this.additionalProperties.put(name, value);
}

}
-----------------------------------br.com.cpsinformatica.relatoriosgerenciais.asynctasks.TOTAL_.java-----------------------------------

package br.com.cpsinformatica.relatoriosgerenciais.asynctasks;

import java.util.HashMap;
import java.util.Map;
import javax.annotation.Generated;

@Generated("org.jsonschema2pojo")
public class TOTAL_ {

private String quantidade;
private String total;
private Map<String, Object> additionalProperties = new HashMap<String, Object>();

/**
* 
* @return
* The quantidade
*/
public String getQuantidade() {
return quantidade;
}

/**
* 
* @param quantidade
* The quantidade
*/
public void setQuantidade(String quantidade) {
this.quantidade = quantidade;
}

/**
* 
* @return
* The total
*/
public String getTotal() {
return total;
}

/**
* 
* @param total
* The total
*/
public void setTotal(String total) {
this.total = total;
}

public Map<String, Object> getAdditionalProperties() {
return this.additionalProperties;
}

public void setAdditionalProperty(String name, Object value) {
this.additionalProperties.put(name, value);
}

}
-----------------------------------br.com.cpsinformatica.relatoriosgerenciais.asynctasks.TOTAL__.java-----------------------------------

package br.com.cpsinformatica.relatoriosgerenciais.asynctasks;

import java.util.HashMap;
import java.util.Map;
import javax.annotation.Generated;

@Generated("org.jsonschema2pojo")
public class TOTAL__ {

private String quantidade;
private String total;
private Map<String, Object> additionalProperties = new HashMap<String, Object>();

/**
* 
* @return
* The quantidade
*/
public String getQuantidade() {
return quantidade;
}

/**
* 
* @param quantidade
* The quantidade
*/
public void setQuantidade(String quantidade) {
this.quantidade = quantidade;
}

/**
* 
* @return
* The total
*/
public String getTotal() {
return total;
}

/**
* 
* @param total
* The total
*/
public void setTotal(String total) {
this.total = total;
}

public Map<String, Object> getAdditionalProperties() {
return this.additionalProperties;
}

public void setAdditionalProperty(String name, Object value) {
this.additionalProperties.put(name, value);
}

}
-----------------------------------br.com.cpsinformatica.relatoriosgerenciais.asynctasks.VISA.java-----------------------------------

package br.com.cpsinformatica.relatoriosgerenciais.asynctasks;

import java.util.HashMap;
import java.util.Map;
import javax.annotation.Generated;

@Generated("org.jsonschema2pojo")
public class VISA {

private String quantidade;
private String valor;
private Map<String, Object> additionalProperties = new HashMap<String, Object>();

/**
* 
* @return
* The quantidade
*/
public String getQuantidade() {
return quantidade;
}

/**
* 
* @param quantidade
* The quantidade
*/
public void setQuantidade(String quantidade) {
this.quantidade = quantidade;
}

/**
* 
* @return
* The valor
*/
public String getValor() {
return valor;
}

/**
* 
* @param valor
* The valor
*/
public void setValor(String valor) {
this.valor = valor;
}

public Map<String, Object> getAdditionalProperties() {
return this.additionalProperties;
}

public void setAdditionalProperty(String name, Object value) {
this.additionalProperties.put(name, value);
}

}
-----------------------------------br.com.cpsinformatica.relatoriosgerenciais.asynctasks.VISA_.java-----------------------------------

package br.com.cpsinformatica.relatoriosgerenciais.asynctasks;

import java.util.HashMap;
import java.util.Map;
import javax.annotation.Generated;

@Generated("org.jsonschema2pojo")
public class VISA_ {

private String quantidade;
private String valor;
private Map<String, Object> additionalProperties = new HashMap<String, Object>();

/**
* 
* @return
* The quantidade
*/
public String getQuantidade() {
return quantidade;
}

/**
* 
* @param quantidade
* The quantidade
*/
public void setQuantidade(String quantidade) {
this.quantidade = quantidade;
}

/**
* 
* @return
* The valor
*/
public String getValor() {
return valor;
}

/**
* 
* @param valor
* The valor
*/
public void setValor(String valor) {
this.valor = valor;
}

public Map<String, Object> getAdditionalProperties() {
return this.additionalProperties;
}

public void setAdditionalProperty(String name, Object value) {
this.additionalProperties.put(name, value);
}

}
-----------------------------------br.com.cpsinformatica.relatoriosgerenciais.asynctasks.VISA__.java-----------------------------------

package br.com.cpsinformatica.relatoriosgerenciais.asynctasks;

import java.util.HashMap;
import java.util.Map;
import javax.annotation.Generated;

@Generated("org.jsonschema2pojo")
public class VISA__ {

private String quantidade;
private String valor;
private Map<String, Object> additionalProperties = new HashMap<String, Object>();

/**
* 
* @return
* The quantidade
*/
public String getQuantidade() {
return quantidade;
}

/**
* 
* @param quantidade
* The quantidade
*/
public void setQuantidade(String quantidade) {
this.quantidade = quantidade;
}

/**
* 
* @return
* The valor
*/
public String getValor() {
return valor;
}

/**
* 
* @param valor
* The valor
*/
public void setValor(String valor) {
this.valor = valor;
}

public Map<String, Object> getAdditionalProperties() {
return this.additionalProperties;
}

public void setAdditionalProperty(String name, Object value) {
this.additionalProperties.put(name, value);
}

}
-----------------------------------br.com.cpsinformatica.relatoriosgerenciais.asynctasks.VOUCHER.java-----------------------------------

package br.com.cpsinformatica.relatoriosgerenciais.asynctasks;

import java.util.HashMap;
import java.util.Map;
import javax.annotation.Generated;

@Generated("org.jsonschema2pojo")
public class VOUCHER {

private MASTERCARD__ MASTERCARD;
private VISA__ VISA;
private TOTAL__ TOTAL;
private Map<String, Object> additionalProperties = new HashMap<String, Object>();

/**
* 
* @return
* The MASTERCARD
*/
public MASTERCARD__ getMASTERCARD() {
return MASTERCARD;
}

/**
* 
* @param MASTERCARD
* The MASTERCARD
*/
public void setMASTERCARD(MASTERCARD__ MASTERCARD) {
this.MASTERCARD = MASTERCARD;
}

/**
* 
* @return
* The VISA
*/
public VISA__ getVISA() {
return VISA;
}

/**
* 
* @param VISA
* The VISA
*/
public void setVISA(VISA__ VISA) {
this.VISA = VISA;
}

/**
* 
* @return
* The TOTAL
*/
public TOTAL__ getTOTAL() {
return TOTAL;
}

/**
* 
* @param TOTAL
* The TOTAL
*/
public void setTOTAL(TOTAL__ TOTAL) {
this.TOTAL = TOTAL;
}

public Map<String, Object> getAdditionalProperties() {
return this.additionalProperties;
}

public void setAdditionalProperty(String name, Object value) {
this.additionalProperties.put(name, value);
}

}