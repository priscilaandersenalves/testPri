package br.com.cpsinformatica.relatoriosgerenciais.adapters;

import android.content.Context;
import android.graphics.Color;
import android.support.v7.widget.RecyclerView;
import android.text.Editable;
import android.text.SpannableStringBuilder;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.LinearLayout;
import android.widget.RelativeLayout;
import android.widget.TextView;

import java.text.NumberFormat;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;

import br.com.cpsinformatica.relatoriosgerenciais.Networking.CarregaRelatorioTotais;
import br.com.cpsinformatica.relatoriosgerenciais.R;
import br.com.cpsinformatica.relatoriosgerenciais.fragments.FragmentTotais;
import br.com.cpsinformatica.relatoriosgerenciais.totais.RelatorioDeTotais;
import br.com.cpsinformatica.relatoriosgerenciais.utils.ConverterMonetario;
import lecho.lib.hellocharts.model.PieChartData;
import lecho.lib.hellocharts.model.SliceValue;
import lecho.lib.hellocharts.util.ChartUtils;
import lecho.lib.hellocharts.view.PieChartView;

/**
 * Created by rodrigo on 11/02/16.
 */
public class MyAdapterTotais extends  RecyclerView.Adapter<RecyclerView.ViewHolder> {

    private RelatorioDeTotais relatorioDeTotais;
    private FragmentTotais mFragment;
    private HashMap<String, Long> map;
    private PieChartData data;
    private HashMap<Integer, LinearLayout> mapPosition;

    private static final int TYPE_HEADER = 0;
    private static final int TYPE_ITEM = 1;

    // Provide a suitable constructor (depends on the kind of dataset)
    public MyAdapterTotais(CarregaRelatorioTotais relatorioTotais, FragmentTotais fragmentTotais) {
        this.mFragment = fragmentTotais;
        this.relatorioDeTotais = relatorioTotais.getRelatorioDeTotais();
        this.map = relatorioTotais.getHasMap();
        this.mapPosition = new HashMap<>();
    }

    public FragmentTotais getFragment(){
        return mFragment;
    }

    @Override
    public RecyclerView.ViewHolder onCreateViewHolder(ViewGroup parent, int viewType) {

        if(viewType == TYPE_HEADER){

            View v = LayoutInflater.from(parent.getContext()).inflate(R.layout.recycle_header_totais, parent, false);
            HeaderViewHolder hvh = new HeaderViewHolder(v);
            return hvh;

        }else if (viewType == TYPE_ITEM){

            View v = LayoutInflater.from(parent.getContext()).inflate(R.layout.recycle_view_card_totais, parent, false);
            ViewHolder vh = new ViewHolder(v);
            return vh;

        }
        return null;
    }

    @Override
    public void onBindViewHolder(RecyclerView.ViewHolder holder, int position) {

        if(holder instanceof HeaderViewHolder) {

            String cabecalho = relatorioDeTotais.getCabecalhoTotais().getEstabelecimento() + "\n" +
                    relatorioDeTotais.getCabecalhoTotais().getEndereco() + "\n" +
                    relatorioDeTotais.getCabecalhoTotais().getCidade() + "\n" +
                    relatorioDeTotais.getCabecalhoTotais().getPos();
            ((HeaderViewHolder) holder).txtCabecalho.setText(cabecalho);
            ((HeaderViewHolder) holder).txtPeriodo.setText("DE: " + relatorioDeTotais.getCabecalhoTotais().getDatetime());

            ((HeaderViewHolder) holder).txtTotalGeral.setText("TOTAL GERAL");
            ((HeaderViewHolder) holder).txtGeralTrans.setText(relatorioDeTotais.getFooterTotalGeral().getQtdGeral() + " TRANS.");
            ((HeaderViewHolder) holder).txtGeralValor.setText(relatorioDeTotais.getFooterTotalGeral().getTotalGeral());
            ((HeaderViewHolder) holder).txtCancelGeral.setText("CANCELAMENTOS");
            ((HeaderViewHolder) holder).txtCancelTrans.setText(relatorioDeTotais.getFooterTotalGeral().getQtdCancel() + " TRANS.");
            ((HeaderViewHolder) holder).txtCancelValor.setText(relatorioDeTotais.getFooterTotalGeral().getTotalCancel());

            //((HeaderViewHolder) holder).pieChart.setOnValueTouchListener(new ValueTouchListener());

            generateData(((HeaderViewHolder) holder));

        }else if (holder instanceof  ViewHolder){

            position -= 1;

            // Obtem elemento do conjunto de dados nesta posição.
            // Substitui o conteúdo da vista com esse elemento.
            ((ViewHolder) holder).mTextView.setText("TOTAL " + relatorioDeTotais.getFormasPagamentosList().get(position).getFormaPagamento());

            if(!mapPosition.containsKey(position)) {

                // Infla o layout dos TextViews de produtos agrupados (MASTERCARD, VISA, ETC) e seta os valores
                LayoutInflater inflater = (LayoutInflater) mFragment.getActivity().getSystemService(Context.LAYOUT_INFLATER_SERVICE);
                int size = relatorioDeTotais.getFormasPagamentosList().get(position).getDetalhePagamentoList().size();
                for (int i = 0; i < size; i++) {

                    View viewProdutos = inflater.inflate(R.layout.itens_totais, null);

                    ViewHolderItensView viewHolderItensView = new ViewHolderItensView(viewProdutos);
                    ((ViewHolder) holder).mLayout.addView(viewAdd(viewHolderItensView, viewProdutos, position, i));

                    mapPosition.put(position, ((ViewHolder) holder).mLayout);
                }

                int countItem = getItemCount() - 2;
                if (position == countItem) {

                    ((ViewHolder) holder).mLayoutFooter.setVisibility(View.VISIBLE);

                    ((ViewHolder) holder).txtUmaCompra.setText(relatorioDeTotais.getFooterRecorrencia().getUmaCompra() + " CLIENTES COM 1 COMPRA");
                    ((ViewHolder) holder).txtDuasCompras.setText(relatorioDeTotais.getFooterRecorrencia().getDuasCompras() + " CLIENTES COM 2 COMPRAS");
                    ((ViewHolder) holder).txtTresOuMais.setText(relatorioDeTotais.getFooterRecorrencia().getTresOuMaisCompras() + " CLIENTES COM 3 OU MAIS COMPRAS");
                }
            }
        }
    }

    private void generateData(HeaderViewHolder holder) {

        int count = 0;
        String[] str = new String[map.size()];
        for (String key : map.keySet()){
            str[count] = key;
            count++;
        }

        List<SliceValue> values = new ArrayList<SliceValue>();
        for (int i = 0; i < map.size(); ++i) {

            SliceValue sliceValue = new SliceValue(map.get(str[i]), ChartUtils.pickColor());

            // Altera a string para valor monetário com R$
            Editable editable = ConverterMonetario.convertString(map.get(str[i]).toString());

            sliceValue.setLabel(str[i] + " " + editable.toString());
            sliceValue.getDarkenColor();

            // Altera a cor do gráfico conforme a posção
            switch (str[i]){
                case "CREDITO":
                    sliceValue.setColor(Color.parseColor("#1599DF"));
                    break;
                case "DEBITO":
                    sliceValue.setColor(Color.parseColor("#B0C300"));
                    break;
                case "OUTROS":
                    sliceValue.setColor(Color.parseColor("#E83A03"));
                    break;
                case "VALE REFEICAO":
                    sliceValue.setColor(Color.parseColor("#ED8D00"));
                    break;
                default:
                    sliceValue.setColor(Color.parseColor("#0D3260"));
                    break;
            }

            values.add(sliceValue);
        }

        data = new PieChartData(values);
        data.setHasLabels(true);
        data.setHasLabelsOnlyForSelected(false);
        data.setHasLabelsOutside(false);
        data.setHasCenterCircle(false);
        data.setHasLabels(true);

        holder.pieChart.setPieChartData(data);

        holder.pieChart.setCircleFillRatio(0.7f);
    }

    @Override
    public int getItemViewType (int position) {
        if (isPositionHeader(position))
            return TYPE_HEADER;
        else
            return TYPE_ITEM;
    }

    private boolean isPositionHeader(int position) {
        return position == 0;
    }

    @Override
    public int getItemCount() {
        return relatorioDeTotais.getFormasPagamentosList().size()+1;
    }

    /**
     * Metodo responsável por montar os
     * textViews de produtos agrupados
     * @param view
     * @return
     */
    private View viewAdd(ViewHolderItensView holder, View view, int position, int i){

        String strBandeira = relatorioDeTotais.getFormasPagamentosList().get(position).getDetalhePagamentoList().get(i).getBandeira();
        //String strQuantidade = relatorioDeTotais.getFormasPagamentosList().get(position).getDetalhePagamentoList().get(i).getQuantidade() + " TRANS.";
        String strValor = relatorioDeTotais.getFormasPagamentosList().get(position).getDetalhePagamentoList().get(i).getValor();

        holder.txtProduto.setText(strBandeira);
        //txtTrans.setText(strQuantidade);
        holder.txtValor.setText(strValor);

        return view;
    }

    public static class ViewHolderItensView extends RecyclerView.ViewHolder {

        private TextView txtProduto;
        private TextView txtTrans;
        private TextView txtValor;

        //public RelativeLayout mLayoutFooter;

        public ViewHolderItensView(View v) {
            super(v);

            txtProduto = (TextView) v.findViewById(R.id.txtNsu);
            txtTrans   = (TextView) v.findViewById(R.id.txtTime);
            txtValor   = (TextView) v.findViewById(R.id.txtValor);
        }
    }

    // Provide a reference to the views for each data item
    // Complex data items may need more than one view per item, and
    // you provide access to all the views for a data item in a view holder
    public static class ViewHolder extends RecyclerView.ViewHolder {

        private TextView mTextView;
        public LinearLayout mLayout;
        public RelativeLayout mLayoutFooter;

        private TextView txtUmaCompra;
        private TextView txtDuasCompras;
        private TextView txtTresOuMais;

        public ViewHolder(View v) {
            super(v);

            mTextView = (TextView) v.findViewById(R.id.txtTitleTotal);
            mLayout = (LinearLayout) v.findViewById(R.id.layoutProdutos);
            mLayoutFooter = (RelativeLayout) v.findViewById(R.id.layoutFooter);

            // Views do footer de Recorrencia
            txtUmaCompra = (TextView) v.findViewById(R.id.txtUmaCompra);
            txtDuasCompras = (TextView) v.findViewById(R.id.txtDuasCompras);
            txtTresOuMais = (TextView) v.findViewById(R.id.txtTresOuMais);
        }
    }

    // Provide a reference to the views for each data item
    // Complex data items may need more than one view per item, and
    // you provide access to all the views for a data item in a view holder
    public static class HeaderViewHolder extends RecyclerView.ViewHolder {

        private TextView txtCabecalho;
        private TextView txtPeriodo;
        private TextView txtTotalGeral;
        private TextView txtGeralTrans;
        private TextView txtGeralValor;
        private TextView txtCancelGeral;
        private TextView txtCancelTrans;
        private TextView txtCancelValor;
        private PieChartView pieChart;

        public HeaderViewHolder(View v) {
            super(v);
            txtCabecalho = (TextView) v.findViewById(R.id.txtCabecalho);
            txtPeriodo = (TextView) v.findViewById(R.id.txtPeriodo);

            // Views do footer de Totais
            txtTotalGeral = (TextView) v.findViewById(R.id.txtTotalGeral);
            txtGeralTrans = (TextView) v.findViewById(R.id.txtGeralTrans);
            txtGeralValor = (TextView) v.findViewById(R.id.txtGeralValor);
            txtCancelGeral = (TextView) v.findViewById(R.id.txtCancelGeral);
            txtCancelTrans = (TextView) v.findViewById(R.id.txtCancelTrans);
            txtCancelValor = (TextView) v.findViewById(R.id.txtCancelValor);

            // View do gráfico
            pieChart = (PieChartView) v.findViewById(R.id.pieChart);
        }
    }
}
