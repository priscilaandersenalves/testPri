package br.com.cpsinformatica.relatoriosgerenciais.Networking;


import android.graphics.Color;
import android.support.design.widget.Snackbar;
import android.support.v7.widget.RecyclerView;
import android.view.View;

import com.android.volley.DefaultRetryPolicy;
import com.android.volley.Request;
import com.android.volley.RequestQueue;
import com.android.volley.Response;
import com.android.volley.TimeoutError;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.JsonObjectRequest;
import com.android.volley.toolbox.Volley;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;

import br.com.cpsinformatica.relatoriosgerenciais.adapters.MyAdapterDetalhado;
import br.com.cpsinformatica.relatoriosgerenciais.detalhado.CabecalhoDetalhado;
import br.com.cpsinformatica.relatoriosgerenciais.detalhado.DetalhePagamentoDetalhado;
import br.com.cpsinformatica.relatoriosgerenciais.detalhado.FormasPagamentoDetalhado;
import br.com.cpsinformatica.relatoriosgerenciais.detalhado.ProdutosDetalhado;
import br.com.cpsinformatica.relatoriosgerenciais.detalhado.RelatorioDetalhado;
import br.com.cpsinformatica.relatoriosgerenciais.domains.UsuarioLogado;
import br.com.cpsinformatica.relatoriosgerenciais.enums.MensagemErroEnum;
import br.com.cpsinformatica.relatoriosgerenciais.enums.ParseDetalhadoEnum;
import br.com.cpsinformatica.relatoriosgerenciais.enums.ParseTotaisEnum;
import br.com.cpsinformatica.relatoriosgerenciais.fragments.FragmentDetalhes;
import br.com.cpsinformatica.relatoriosgerenciais.totais.FooterTotalGeral;
import br.com.cpsinformatica.relatoriosgerenciais.utils.MyAnimation;
import br.com.cpsinformatica.relatoriosgerenciais.utils.Preferences;
import br.com.cpsinformatica.relatoriosgerenciais.utils.URL;

/**
 * Created by rodrigo on 12/02/16.
 */
public class CarregaRelatorioDetalhado {

    private FragmentDetalhes mFragmentDetalhes;
    private RecyclerView mRecyclerView;
    private MyAdapterDetalhado mAdapter;
    private RelatorioDetalhado relatorioDetalhado;
    private HashMap<String, Long> map;
    private List<String> produtosList;
    private static Snackbar snackbar;

    private static String TAG = CarregaRelatorioDetalhado.class.getSimpleName();

    public CarregaRelatorioDetalhado(FragmentDetalhes mFragmentDetalhes){
        this.mFragmentDetalhes = mFragmentDetalhes;
        this.mRecyclerView = mFragmentDetalhes.getRecyclerView();
        this.map = new HashMap<>();
        this.produtosList = new ArrayList<>();
    }

    public void request(final String dataIni, final String horaIni, final String dataFim, final String horaFim){

        // Esconde SnackBar se estiver visível
        if(snackbar != null && snackbar.getView().getVisibility() == View.VISIBLE){
            snackbar.dismiss();
        }

        // Exibe icone de Progress na tela
        mFragmentDetalhes.getProgressBar().setVisibility(View.VISIBLE);

        // Trata o retorno do webservice de totais
        Response.Listener<JSONObject> successListener = new Response.Listener<JSONObject>() {
            @Override
            public void onResponse(JSONObject jsonObject) {

                try {

                    List<FormasPagamentoDetalhado> formasPagamentosList = new ArrayList<>();
                    List<ProdutosDetalhado> produtosDetalhadoList = new ArrayList<>();

                    relatorioDetalhado = new RelatorioDetalhado();
                    relatorioDetalhado.setStatus(jsonObject.getBoolean(ParseDetalhadoEnum.STATUS.getText()));
                    relatorioDetalhado.setMensagem(jsonObject.getString(ParseDetalhadoEnum.MENSAGEM.getText()));

                    System.out.println(TAG + " " + jsonObject.getString(ParseDetalhadoEnum.MENSAGEM.getText()));

                    if (relatorioDetalhado.isStatus()) {

                        JSONObject arrayCabecalho = jsonObject.getJSONObject(ParseDetalhadoEnum.CABECALHO.getText());

                        CabecalhoDetalhado cabecalhoDetalhado = new CabecalhoDetalhado();
                        cabecalhoDetalhado.setEstabelecimento(arrayCabecalho.getString(ParseDetalhadoEnum.ESTABELECIMENTO.getText()));
                        cabecalhoDetalhado.setEndereco(arrayCabecalho.getString(ParseDetalhadoEnum.ENDERECO.getText()));
                        cabecalhoDetalhado.setCidade(arrayCabecalho.getString(ParseDetalhadoEnum.CIDADE.getText()));
                        cabecalhoDetalhado.setPos(arrayCabecalho.getInt(ParseDetalhadoEnum.POS.getText()));
                        cabecalhoDetalhado.setDatetime(arrayCabecalho.getString(ParseDetalhadoEnum.DATETIME.getText()));

                        relatorioDetalhado.setCabecalhoDetalhado(cabecalhoDetalhado);

                        JSONObject objectFormasPagamento = jsonObject.getJSONObject(ParseDetalhadoEnum.FORMAS_PAGAMENTO.getText());

                        Iterator iteratorFormasPGTO = objectFormasPagamento.keys();
                        while (iteratorFormasPGTO.hasNext()) {

                            List<DetalhePagamentoDetalhado> detalhePagamentoList = new ArrayList<>();

                            String forma = (String) iteratorFormasPGTO.next();

                            if(!map.containsKey(forma)){
                                map.put(forma, Long.valueOf(0));
                            }

                            FormasPagamentoDetalhado formasPagamento = new FormasPagamentoDetalhado();
                            formasPagamento.setFormaPagamento(forma);
                            formasPagamentosList.add(formasPagamento);

                            JSONObject objectBandeiras = objectFormasPagamento.getJSONObject(forma);

                            Iterator iteratorBandeira = objectBandeiras.keys();
                            while (iteratorBandeira.hasNext()) {

                                String produto = (String) iteratorBandeira.next();

                                ProdutosDetalhado produtosDetalhado = new ProdutosDetalhado();
                                produtosDetalhado.setProduto(produto);
                                produtosDetalhadoList.add(produtosDetalhado);

                                produtosList.add(produto);

                                JSONArray bandeiras = objectBandeiras.getJSONArray(produto);

                                int length = bandeiras.length();
                                for (int i = 0; i < length; i++) {

                                    JSONObject objectPagamento = (JSONObject) bandeiras.get(i);

                                    DetalhePagamentoDetalhado detalhePagamento = new DetalhePagamentoDetalhado();

                                    if(produto.contains("TOTAL")){

                                        detalhePagamento.setBandeira(objectPagamento.getString(ParseDetalhadoEnum.BANDEIRA.getText()));
                                        detalhePagamento.setValor(objectPagamento.getString(ParseDetalhadoEnum.VALOR.getText()));
                                        detalhePagamento.setQuantidade(objectPagamento.getString(ParseDetalhadoEnum.QUANTIDADE.getText()));

                                    }else {

                                        detalhePagamento.setBandeira(objectPagamento.getString(ParseDetalhadoEnum.BANDEIRA.getText()));
                                        detalhePagamento.setNsu(objectPagamento.getString(ParseDetalhadoEnum.NSU.getText()));
                                        detalhePagamento.setData(objectPagamento.getString(ParseDetalhadoEnum.DATA.getText()));
                                        detalhePagamento.setHora(objectPagamento.getString(ParseDetalhadoEnum.HORA.getText()));
                                        detalhePagamento.setStatusTransacao(objectPagamento.getString(ParseDetalhadoEnum.STATUS_TRANSAC.getText()));
                                        detalhePagamento.setValor(objectPagamento.getString(ParseDetalhadoEnum.VALOR.getText()));

                                    }
                                    detalhePagamentoList.add(detalhePagamento);
                                    formasPagamento.setDetalhePagamentoList(detalhePagamentoList);


                                    /**
                                     *  Esse código é responsável por
                                     *  capturar as informações do gráfico
                                     *  do cabeçalho
                                     */
                                    if(detalhePagamento.getBandeira().contains("TOTAL")) {
                                        String valuePgto = detalhePagamento.getValor().replaceAll("\\.", "").replace(",", "");
                                        long value = Long.parseLong(valuePgto);
                                        long longMap = map.get(forma);

                                        long result = longMap + value;

                                        map.put(forma, result);
                                    }
                                }
                            }
                        }

                        relatorioDetalhado.setFormasPagamentosList(formasPagamentosList);
                        relatorioDetalhado.setProdutosDetalhadoList(produtosDetalhadoList);

                        int sizePgto = formasPagamentosList.size();
                        for (int e = 0; e < sizePgto; e ++){

                            int sizeListPgto = relatorioDetalhado.getFormasPagamentosList().get(e).getDetalhePagamentoList().size();
                            for (int f = 0; f < sizeListPgto; f ++){
                                if(relatorioDetalhado.getFormasPagamentosList().get(e).getDetalhePagamentoList().get(f).getBandeira().contains("TOTAL")){
                                    DetalhePagamentoDetalhado detalhePgto = relatorioDetalhado.getFormasPagamentosList().get(e).getDetalhePagamentoList().get(f);
                                    relatorioDetalhado.getFormasPagamentosList().get(e).getDetalhePagamentoList().remove(f);
                                    relatorioDetalhado.getFormasPagamentosList().get(e).getDetalhePagamentoList().add(detalhePgto);

                                    int a = 2;
                                    int b = 6;
                                    int c = a+b;
                                }
                            }
                        }

                        // Cria o objeto que preenche o rodapé de TOTAIS
                        JSONObject arrayTotalGeral = jsonObject.getJSONObject(ParseTotaisEnum.TOTAL_GERAL_UPP.getText());
                        FooterTotalGeral footerTotalGeral = new FooterTotalGeral();
                        footerTotalGeral.setQtdCancel(arrayTotalGeral.getInt(ParseTotaisEnum.QTDE_CANCEL.getText()));
                        footerTotalGeral.setTotalCancel(arrayTotalGeral.getString(ParseTotaisEnum.TOTAL_CANCEL.getText()));
                        footerTotalGeral.setQtdGeral(arrayTotalGeral.getInt(ParseTotaisEnum.QTDE_GERAL.getText()));
                        footerTotalGeral.setTotalGeral(arrayTotalGeral.getString(ParseTotaisEnum.TOTAL_GERAL.getText()));
                        relatorioDetalhado.setFooterTotalGeral(footerTotalGeral);

                        // specify an adapter (see also next example)
                        mAdapter = new MyAdapterDetalhado(CarregaRelatorioDetalhado.this, mFragmentDetalhes);
                        mRecyclerView.setAdapter(mAdapter);
                        MyAnimation.animationFadeIn(mRecyclerView);

                    } else {

                        mRecyclerView.setAdapter(null);
                        snackMessageActionTENTAR(relatorioDetalhado.getMensagem(), dataIni, horaIni, dataFim, horaFim);
                    }
                }catch (JSONException e){
                    mRecyclerView.setAdapter(null);
                    Snackbar snackbar = Snackbar.make(mFragmentDetalhes.getActivity().findViewById(android.R.id.content), e.getMessage(), Snackbar.LENGTH_LONG);
                    snackbar.show();
                }

                mFragmentDetalhes.getProgressBar().setVisibility(View.INVISIBLE);
            }
        };

        Response.ErrorListener errorListener = new Response.ErrorListener() {
            @Override
            public void onErrorResponse(VolleyError volleyError) {

                if (volleyError.networkResponse == null) {
                    if (volleyError.getClass().equals(TimeoutError.class)) {
                        snackMessageActionTENTAR(MensagemErroEnum.TEMPO_EXCEDIDO.getText(), dataIni, horaIni, dataFim, horaFim);
                    }else {
                        snackMessageActionTENTAR(MensagemErroEnum.SEM_CONEXAO.getText(), dataIni, horaIni, dataFim, horaFim);
                    }
                }
                mRecyclerView.setAdapter(mAdapter);
                mFragmentDetalhes.getProgressBar().setVisibility(View.INVISIBLE);
            }
        };

        // Efetua a requisição do webservice
        String url = String.format(URL.REL_DETALHADO, Preferences.getIP(mFragmentDetalhes.getActivity()), dataIni, horaIni, dataFim, horaFim, UsuarioLogado.getUsuario());

        System.out.println(url);

        JsonObjectRequest request = new JsonObjectRequest(Request.Method.GET, url, successListener, errorListener);
        request.setRetryPolicy(new DefaultRetryPolicy(
                15000,
                DefaultRetryPolicy.DEFAULT_MAX_RETRIES,
                DefaultRetryPolicy.DEFAULT_BACKOFF_MULT));
        RequestQueue mQueue = Volley.newRequestQueue(mFragmentDetalhes.getActivity());
        mQueue.add(request);
    }

    public RelatorioDetalhado getRelatorioDetalhado(){
        return relatorioDetalhado;
    }

    private void snackMessageActionTENTAR(String mensagem, final String dataIni, final String horaIni, final String dataFim, final String horaFim){

        snackbar = Snackbar.make(mFragmentDetalhes.getActivity().findViewById(android.R.id.content), mensagem, Snackbar.LENGTH_INDEFINITE)
                .setAction(MensagemErroEnum.TENTAR.getText(), new View.OnClickListener() {
                    @Override
                    public void onClick(View v) {

                        // Callback recursivo da requisição de pagamento
                        mFragmentDetalhes.getProgressBar().setVisibility(View.VISIBLE);
                        CarregaRelatorioDetalhado.this.request(dataIni, horaIni, dataFim, horaFim);
                    }
                });
        snackbar.setActionTextColor(Color.parseColor("#008ec2"));
        snackbar.show();
    }

    public List<String> getProdutosList(){
        return produtosList;
    }

    public HashMap<String, Long> getHasMap(){
        return map;
    }

    public static void snackbarDismiss(){
        snackbar.dismiss();
    }

    public static Snackbar getSnackbar(){
        return snackbar;
    }
}