package br.com.cpsinformatica.relatoriosgerenciais.adapters;

import android.content.Context;
import android.graphics.Color;
import android.support.v7.widget.RecyclerView;
import android.text.Editable;
import android.text.SpannableStringBuilder;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.LinearLayout;
import android.widget.RelativeLayout;
import android.widget.TextView;

import java.text.NumberFormat;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;

import br.com.cpsinformatica.relatoriosgerenciais.Networking.CarregaRelatorioDetalhado;
import br.com.cpsinformatica.relatoriosgerenciais.R;
import br.com.cpsinformatica.relatoriosgerenciais.detalhado.RelatorioDetalhado;
import br.com.cpsinformatica.relatoriosgerenciais.fragments.FragmentDetalhes;
import br.com.cpsinformatica.relatoriosgerenciais.utils.ConverterMonetario;
import lecho.lib.hellocharts.model.PieChartData;
import lecho.lib.hellocharts.model.SliceValue;
import lecho.lib.hellocharts.util.ChartUtils;
import lecho.lib.hellocharts.view.PieChartView;

/**
 * Created by rodrigo on 11/02/16.
 */
public class MyAdapterDetalhado extends  RecyclerView.Adapter<RecyclerView.ViewHolder> {


    private RelatorioDetalhado relatorioDetalhado;
    private FragmentDetalhes mFragment;
    private HashMap<String, Long> map;
    private List<String> produtoList;
    private PieChartData data;
    private String produtoText;
    private HashMap<Integer, LinearLayout> mapLayout;

    private static final int TYPE_HEADER = 0;
    private static final int TYPE_ITEM = 1;

    // Provide a suitable constructor (depends on the kind of dataset)
    public MyAdapterDetalhado(CarregaRelatorioDetalhado relatorioDetalhado, FragmentDetalhes fragmentDetalhes) {
        this.mFragment = fragmentDetalhes;
        this.relatorioDetalhado = relatorioDetalhado.getRelatorioDetalhado();
        this.map = relatorioDetalhado.getHasMap();
        this.produtoList = relatorioDetalhado.getProdutosList();
        this.mapLayout = new HashMap<>();
    }

    @Override
    public RecyclerView.ViewHolder onCreateViewHolder(ViewGroup parent, int viewType) {

        if(viewType == TYPE_HEADER){

            View v = LayoutInflater.from(parent.getContext()).inflate(R.layout.recycle_header_detalhado, parent, false);
            HeaderViewHolder hvh = new HeaderViewHolder(v);
            return hvh;

        }else if (viewType == TYPE_ITEM){

            View v = LayoutInflater.from(parent.getContext()).inflate(R.layout.recycle_view_card_detalhes, parent, false);
            ViewHolder vh = new ViewHolder(v);
            return vh;

        }
        return null;
    }

    @Override
    public void onBindViewHolder(RecyclerView.ViewHolder holder, int position) {

        if(holder instanceof HeaderViewHolder) {

            String cabecalho = relatorioDetalhado.getCabecalhoDetalhado().getEstabelecimento() + "\n" +
                    relatorioDetalhado.getCabecalhoDetalhado().getEndereco() + "\n" +
                    relatorioDetalhado.getCabecalhoDetalhado().getCidade() + "\n" +
                    relatorioDetalhado.getCabecalhoDetalhado().getPos();
            ((HeaderViewHolder) holder).txtCabecalho.setText(cabecalho);
            ((HeaderViewHolder) holder).txtPeriodo.setText("DE: " + relatorioDetalhado.getCabecalhoDetalhado().getDatetime());

            ((HeaderViewHolder) holder).txtTotalGeral.setText("TOTAL GERAL");
            ((HeaderViewHolder) holder).txtGeralTrans.setText(relatorioDetalhado.getFooterTotalGeral().getQtdGeral() + " TRANS.");
            ((HeaderViewHolder) holder).txtGeralValor.setText(relatorioDetalhado.getFooterTotalGeral().getTotalGeral());
            ((HeaderViewHolder) holder).txtCancelGeral.setText("CANCELAMENTOS");
            ((HeaderViewHolder) holder).txtCancelTrans.setText(relatorioDetalhado.getFooterTotalGeral().getQtdCancel() + " TRANS.");
            ((HeaderViewHolder) holder).txtCancelValor.setText(relatorioDetalhado.getFooterTotalGeral().getTotalCancel());

            generateData(((HeaderViewHolder) holder));

        }else if (holder instanceof  ViewHolder){

            position -= 1;

            // Obtem elemento do conjunto de dados nesta posição.
            // Substitui o conteúdo da vista com esse elemento.
            ((ViewHolder) holder).mTextView.setText(relatorioDetalhado.getFormasPagamentosList().get(position).getFormaPagamento());

            if(!mapLayout.containsKey(position)) {

                // Infla o layout dos TextViews de produtos agrupados (MASTERCARD, VISA, ETC) e seta os valores
                LayoutInflater inflater = (LayoutInflater) mFragment.getActivity().getSystemService(Context.LAYOUT_INFLATER_SERVICE);
                int size = relatorioDetalhado.getFormasPagamentosList().get(position).getDetalhePagamentoList().size();

                produtoText = "";
                for (int i = 0; i < size; i++) {

                    View viewProdutos = inflater.inflate(R.layout.itens_detalhes, null);

                    ViewHolderItensView viewHolderItensView = new ViewHolderItensView(viewProdutos);
                    ((ViewHolder) holder).mLayout.addView(viewAdd(viewHolderItensView, viewProdutos, position, i));

                    mapLayout.put(position, ((ViewHolder) holder).mLayout);
                }
            }

            int countItem = getItemCount()-2;
            if(position == countItem){

                //((ViewHolder) holder).mLayoutFooter.setVisibility(View.VISIBLE);

            }
        }
    }

    private void generateData(HeaderViewHolder holder) {

        int count = 0;
        String[] str = new String[map.size()];
        for (String key : map.keySet()){
            str[count] = key;
            count++;
        }

        List<SliceValue> values = new ArrayList<SliceValue>();
        for (int i = 0; i < map.size(); ++i) {

            SliceValue sliceValue = new SliceValue(map.get(str[i]), ChartUtils.pickColor());

            // Altera a string para valor monetário com R$
            Editable editable = ConverterMonetario.convertString(map.get(str[i]).toString());

            sliceValue.setLabel(str[i] + " " + editable.toString());
            sliceValue.getDarkenColor();

            // Altera a cor do gráfico conforme a posção
            switch (str[i]){
                case "CREDITO":
                    sliceValue.setColor(Color.parseColor("#1599DF"));
                    break;
                case "DEBITO":
                    sliceValue.setColor(Color.parseColor("#B0C300"));
                    break;
                case "OUTROS":
                    sliceValue.setColor(Color.parseColor("#E83A03"));
                    break;
                case "VALE REFEICAO":
                    sliceValue.setColor(Color.parseColor("#ED8D00"));
                    break;
                default:
                    sliceValue.setColor(Color.parseColor("#0D3260"));
                    break;
            }

            values.add(sliceValue);
        }

        data = new PieChartData(values);
        data.setHasLabels(true);
        data.setHasLabelsOnlyForSelected(false);
        data.setHasLabelsOutside(false);
        data.setHasCenterCircle(false);
        data.setHasLabels(true);

        holder.pieChart.setPieChartData(data);

        holder.pieChart.setCircleFillRatio(0.7f);
    }

    @Override
    public int getItemViewType (int position) {
        if (isPositionHeader(position))
            return TYPE_HEADER;
        else
            return TYPE_ITEM;
    }

    private boolean isPositionHeader(int position) {
        return position == 0;
    }

    @Override
    public int getItemCount() {
        return relatorioDetalhado.getFormasPagamentosList().size()+1;
    }

    /**
     * Metodo responsável por montar os
     * textViews de produtos agrupados
     * @param view
     * @return
     */
    private View viewAdd(ViewHolderItensView holder, View view, int position, int i){

        String produtoCurrent = relatorioDetalhado.getFormasPagamentosList().get(position).getDetalhePagamentoList().get(i).getBandeira();
        if (!produtoCurrent.equals(produtoText)){
            holder.txtProduto.setVisibility(View.VISIBLE);
            produtoText = produtoCurrent;
        }

        String strNsu = relatorioDetalhado.getFormasPagamentosList().get(position).getDetalhePagamentoList().get(i).getNsu();
        String strData = relatorioDetalhado.getFormasPagamentosList().get(position).getDetalhePagamentoList().get(i).getData();
        String strHora = relatorioDetalhado.getFormasPagamentosList().get(position).getDetalhePagamentoList().get(i).getHora();
        String strValor = relatorioDetalhado.getFormasPagamentosList().get(position).getDetalhePagamentoList().get(i).getValor();

        if(produtoCurrent.indexOf("TOTAL_") == -1){

            holder.txtProduto.setText(produtoCurrent);
            holder.txtNsu.setText(strNsu);
            holder.txtHora.setText(strHora + "  " + strData);
            holder.txtValor.setText(strValor);

        }else{

            // Altera a string para valor monetário com R$
            Editable editableValor = ConverterMonetario.convertString(strValor);

            holder.txtProduto.setText(produtoCurrent);
            holder.txtValor.setText(editableValor);
            holder.txtHora.setText(relatorioDetalhado.getFormasPagamentosList().get(position).getDetalhePagamentoList().get(i).getQuantidade() + " TRANS.");
            holder.txtNsu.setText("TOTAL:");

            holder.txtProduto.setTextColor(Color.BLACK);
            holder.txtValor.setTextColor(Color.BLACK);
            holder.txtHora.setTextColor(Color.BLACK);
            holder.txtNsu.setTextColor(Color.BLACK);

            view.setBackgroundColor(Color.parseColor("#c1c1c1"));

            // Adiciona uma marem extra na view
            view.setPadding(view.getPaddingLeft(), view.getPaddingTop() + 20, view.getPaddingRight(), view.getPaddingBottom() + 20);
        }

        return view;
    }

    public static class ViewHolderItensView extends RecyclerView.ViewHolder {

        private TextView txtProduto;
        private TextView txtNsu;
        private TextView txtHora;
        private TextView txtValor;

        //public RelativeLayout mLayoutFooter;

        public ViewHolderItensView(View v) {
            super(v);

            txtProduto = (TextView) v.findViewById(R.id.textProduto);
            txtNsu = (TextView) v.findViewById(R.id.txtNsu);
            txtHora = (TextView) v.findViewById(R.id.txtHora);
            txtValor = (TextView) v.findViewById(R.id.txtValor);
        }
    }

    // Provide a reference to the views for each data item
    // Complex data items may need more than one view per item, and
    // you provide access to all the views for a data item in a view holder
    public static class ViewHolder extends RecyclerView.ViewHolder {

        private TextView mTextView;
        public LinearLayout mLayout;
        public RelativeLayout mLayoutFooter;

        public ViewHolder(View v) {
            super(v);

            mTextView = (TextView) v.findViewById(R.id.txtTitleDetalhe);
            mLayout = (LinearLayout) v.findViewById(R.id.layoutProdutos);
            mLayoutFooter = (RelativeLayout) v.findViewById(R.id.layoutFooter);
        }
    }

    // Provide a reference to the views for each data item
    // Complex data items may need more than one view per item, and
    // you provide access to all the views for a data item in a view holder
    public static class HeaderViewHolder extends RecyclerView.ViewHolder {

        private TextView txtCabecalho;
        private TextView txtPeriodo;
        private TextView txtTotalGeral;
        private TextView txtGeralTrans;
        private TextView txtGeralValor;
        private TextView txtCancelGeral;
        private TextView txtCancelTrans;
        private TextView txtCancelValor;
        private PieChartView pieChart;

        public HeaderViewHolder(View v) {
            super(v);
            txtCabecalho = (TextView) v.findViewById(R.id.txtCabecalho);
            txtPeriodo = (TextView) v.findViewById(R.id.txtPeriodo);

            // Views do footer de Detalhes
            txtTotalGeral = (TextView) v.findViewById(R.id.txtTotalGeral);
            txtGeralTrans = (TextView) v.findViewById(R.id.txtGeralTrans);
            txtGeralValor = (TextView) v.findViewById(R.id.txtGeralValor);
            txtCancelGeral = (TextView) v.findViewById(R.id.txtCancelGeral);
            txtCancelTrans = (TextView) v.findViewById(R.id.txtCancelTrans);
            txtCancelValor = (TextView) v.findViewById(R.id.txtCancelValor);

            // View do gráfico
            pieChart = (PieChartView) v.findViewById(R.id.pieChart);
        }
    }
}
