package br.com.cpsinformatica.relatoriosgerenciais.domains;

/**
 * Created by rodrigo on 26/02/16.
 */
public class UsuarioLogado {

    private static String usuario;

    public static String getUsuario() {
        return usuario;
    }

    public static void setUsuario(String usuario) {
        UsuarioLogado.usuario = usuario;
    }
}
