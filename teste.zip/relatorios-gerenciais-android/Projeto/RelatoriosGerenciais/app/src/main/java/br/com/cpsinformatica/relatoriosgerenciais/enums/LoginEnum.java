package br.com.cpsinformatica.relatoriosgerenciais.enums;

/**
 * Created by rodrigo on 17/02/16.
 */
public enum LoginEnum {

    STATUS("status"),
    MENSAGEM("mensagem");

    private String valor;

    LoginEnum(String str){
        valor = str;
    }

    public String getText(){
        return valor;
    }
}
