
package br.com.cpsinformatica.relatoriosgerenciais.jsonparse;

import java.util.ArrayList;
import java.util.List;
import javax.annotation.Generated;
import javax.validation.Valid;
import com.google.gson.annotations.Expose;
import com.google.gson.annotations.SerializedName;

@Generated("org.jsonschema2pojo")
public class CREDITO {

    @SerializedName("MASTERCARD")
    @Expose
    @Valid
    private List<br.com.cpsinformatica.relatoriosgerenciais.jsonparse.MASTERCARD> MASTERCARD = new ArrayList<br.com.cpsinformatica.relatoriosgerenciais.jsonparse.MASTERCARD>();
    @SerializedName("TOTAL VISA")
    @Expose
    @Valid
    private List<br.com.cpsinformatica.relatoriosgerenciais.jsonparse.TOTALVISA> TOTALVISA = new ArrayList<br.com.cpsinformatica.relatoriosgerenciais.jsonparse.TOTALVISA>();
    @SerializedName("TOTAL MASTERCARD")
    @Expose
    @Valid
    private List<br.com.cpsinformatica.relatoriosgerenciais.jsonparse.TOTALMASTERCARD> TOTALMASTERCARD = new ArrayList<br.com.cpsinformatica.relatoriosgerenciais.jsonparse.TOTALMASTERCARD>();
    @SerializedName("VISA")
    @Expose
    @Valid
    private List<br.com.cpsinformatica.relatoriosgerenciais.jsonparse.VISA> VISA = new ArrayList<br.com.cpsinformatica.relatoriosgerenciais.jsonparse.VISA>();

    /**
     * 
     * @return
     *     The MASTERCARD
     */
    public List<br.com.cpsinformatica.relatoriosgerenciais.jsonparse.MASTERCARD> getMASTERCARD() {
        return MASTERCARD;
    }

    /**
     * 
     * @param MASTERCARD
     *     The MASTERCARD
     */
    public void setMASTERCARD(List<br.com.cpsinformatica.relatoriosgerenciais.jsonparse.MASTERCARD> MASTERCARD) {
        this.MASTERCARD = MASTERCARD;
    }

    /**
     * 
     * @return
     *     The TOTALVISA
     */
    public List<br.com.cpsinformatica.relatoriosgerenciais.jsonparse.TOTALVISA> getTOTALVISA() {
        return TOTALVISA;
    }

    /**
     * 
     * @param TOTALVISA
     *     The TOTAL VISA
     */
    public void setTOTALVISA(List<br.com.cpsinformatica.relatoriosgerenciais.jsonparse.TOTALVISA> TOTALVISA) {
        this.TOTALVISA = TOTALVISA;
    }

    /**
     * 
     * @return
     *     The TOTALMASTERCARD
     */
    public List<br.com.cpsinformatica.relatoriosgerenciais.jsonparse.TOTALMASTERCARD> getTOTALMASTERCARD() {
        return TOTALMASTERCARD;
    }

    /**
     * 
     * @param TOTALMASTERCARD
     *     The TOTAL MASTERCARD
     */
    public void setTOTALMASTERCARD(List<br.com.cpsinformatica.relatoriosgerenciais.jsonparse.TOTALMASTERCARD> TOTALMASTERCARD) {
        this.TOTALMASTERCARD = TOTALMASTERCARD;
    }

    /**
     * 
     * @return
     *     The VISA
     */
    public List<br.com.cpsinformatica.relatoriosgerenciais.jsonparse.VISA> getVISA() {
        return VISA;
    }

    /**
     * 
     * @param VISA
     *     The VISA
     */
    public void setVISA(List<br.com.cpsinformatica.relatoriosgerenciais.jsonparse.VISA> VISA) {
        this.VISA = VISA;
    }

}
