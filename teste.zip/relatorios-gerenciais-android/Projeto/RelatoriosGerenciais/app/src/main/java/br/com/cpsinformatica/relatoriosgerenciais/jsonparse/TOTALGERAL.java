
package br.com.cpsinformatica.relatoriosgerenciais.jsonparse;

import javax.annotation.Generated;
import com.google.gson.annotations.Expose;
import com.google.gson.annotations.SerializedName;

@Generated("org.jsonschema2pojo")
public class TOTALGERAL {

    @SerializedName("qtdeCancel")
    @Expose
    private Integer qtdeCancel;
    @SerializedName("totalCancel")
    @Expose
    private String totalCancel;
    @SerializedName("qtdeGeral")
    @Expose
    private Integer qtdeGeral;
    @SerializedName("totalGeral")
    @Expose
    private String totalGeral;

    /**
     * 
     * @return
     *     The qtdeCancel
     */
    public Integer getQtdeCancel() {
        return qtdeCancel;
    }

    /**
     * 
     * @param qtdeCancel
     *     The qtdeCancel
     */
    public void setQtdeCancel(Integer qtdeCancel) {
        this.qtdeCancel = qtdeCancel;
    }

    /**
     * 
     * @return
     *     The totalCancel
     */
    public String getTotalCancel() {
        return totalCancel;
    }

    /**
     * 
     * @param totalCancel
     *     The totalCancel
     */
    public void setTotalCancel(String totalCancel) {
        this.totalCancel = totalCancel;
    }

    /**
     * 
     * @return
     *     The qtdeGeral
     */
    public Integer getQtdeGeral() {
        return qtdeGeral;
    }

    /**
     * 
     * @param qtdeGeral
     *     The qtdeGeral
     */
    public void setQtdeGeral(Integer qtdeGeral) {
        this.qtdeGeral = qtdeGeral;
    }

    /**
     * 
     * @return
     *     The totalGeral
     */
    public String getTotalGeral() {
        return totalGeral;
    }

    /**
     * 
     * @param totalGeral
     *     The totalGeral
     */
    public void setTotalGeral(String totalGeral) {
        this.totalGeral = totalGeral;
    }

}
