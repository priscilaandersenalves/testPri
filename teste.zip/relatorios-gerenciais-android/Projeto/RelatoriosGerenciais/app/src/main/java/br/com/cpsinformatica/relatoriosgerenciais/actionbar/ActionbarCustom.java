package br.com.cpsinformatica.relatoriosgerenciais.actionbar;

import android.content.Context;
import android.graphics.Color;
import android.graphics.drawable.ColorDrawable;
import android.support.v7.app.ActionBar;
import android.support.v7.app.AppCompatActivity;
import android.view.LayoutInflater;
import android.view.View;
import android.widget.ImageView;

import br.com.cpsinformatica.relatoriosgerenciais.R;

/**
 * Created by rodrigo on 26/01/15.
 */
public class ActionbarCustom {
    public static void addCustomActionbar(AppCompatActivity activity){

        // Cria cor para adicionar ao background da ActionBar
        ColorDrawable colorDrawable = new ColorDrawable(Color.parseColor("#00aeef"));

        LayoutInflater inflater = (LayoutInflater) activity.getSystemService(Context.LAYOUT_INFLATER_SERVICE);
        View view = inflater.inflate(R.layout.actionbar_custom, null);

        ImageView imgLogo = (ImageView) view.findViewById(R.id.actionBarLogo);
        imgLogo.setImageResource(R.drawable.cielo_dark);

        ActionBar actionBar = activity.getSupportActionBar();
        actionBar.setCustomView(view);
        actionBar.setDisplayShowTitleEnabled(false);
        actionBar.setDisplayShowCustomEnabled(true);
        actionBar.setBackgroundDrawable(colorDrawable);

    }
}
