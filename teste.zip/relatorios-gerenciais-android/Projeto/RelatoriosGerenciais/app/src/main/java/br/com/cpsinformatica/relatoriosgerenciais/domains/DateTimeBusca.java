package br.com.cpsinformatica.relatoriosgerenciais.domains;

import br.com.cpsinformatica.relatoriosgerenciais.utils.CapturaDateTime;

/**
 * Created by rodrigo on 29/02/16.
 */
public class DateTimeBusca {

    private static String dataIni;
    private static String horaIni;
    private static String dataFim;
    private static String horaFim;

    public static String getDataIni() {
        return dataIni;
    }

    public static void setDataIni(String dataIni) {
        DateTimeBusca.dataIni = dataIni;
    }

    public static String getHoraIni() {
        return horaIni;
    }

    public static void setHoraIni(String horaIni) {
        DateTimeBusca.horaIni = horaIni;
    }

    public static String getDataFim() {
        return dataFim;
    }

    public static void setDataFim(String dataFim) {
        DateTimeBusca.dataFim = dataFim;
    }

    public static String getHoraFim() {
        return horaFim;
    }

    public static void setHoraFim(String horaFim) {
        DateTimeBusca.horaFim = horaFim;
    }

    public static void setDateTimeHoje(){
        DateTimeBusca.setDataIni(CapturaDateTime.getDataHoje());
        DateTimeBusca.setHoraIni("");
        DateTimeBusca.setDataFim(CapturaDateTime.getDataHoje());
        DateTimeBusca.setHoraFim("");
    }

    public static void setDateTimeOtem(){
        DateTimeBusca.setDataIni(CapturaDateTime.getDataOntem());
        DateTimeBusca.setHoraIni("");
        DateTimeBusca.setDataFim(CapturaDateTime.getDataOntem());
        DateTimeBusca.setHoraFim("");
    }

    public static void setDateTime7Dias(){
        DateTimeBusca.setDataIni(CapturaDateTime.getDataDias(7));
        DateTimeBusca.setHoraIni("");
        DateTimeBusca.setDataFim(CapturaDateTime.getDataHoje());
        DateTimeBusca.setHoraFim("");
    }

    public static void setDateTime15Dias(){
        DateTimeBusca.setDataIni(CapturaDateTime.getDataDias(15));
        DateTimeBusca.setHoraIni("");
        DateTimeBusca.setDataFim(CapturaDateTime.getDataHoje());
        DateTimeBusca.setHoraFim("");
    }

    public static void setDateTimeEsseMes(){
        DateTimeBusca.setDataIni(CapturaDateTime.getDataMes());
        DateTimeBusca.setHoraIni("");
        DateTimeBusca.setDataFim(CapturaDateTime.getDataHoje());
        DateTimeBusca.setHoraFim("");
    }

    public static void setDateTimePersonalizado(String dataIni, String horaIni, String dataFim, String horaFim){
        DateTimeBusca.setDataIni(dataIni);
        DateTimeBusca.setHoraIni(horaIni);
        DateTimeBusca.setDataFim(dataFim);
        DateTimeBusca.setHoraFim(horaFim);
    }
}
