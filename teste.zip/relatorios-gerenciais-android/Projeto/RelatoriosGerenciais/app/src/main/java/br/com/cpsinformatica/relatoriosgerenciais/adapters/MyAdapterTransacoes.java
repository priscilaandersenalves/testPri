package br.com.cpsinformatica.relatoriosgerenciais.adapters;

import android.graphics.Color;
import android.support.v7.widget.RecyclerView;
import android.text.Editable;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;

import br.com.cpsinformatica.relatoriosgerenciais.Networking.CarregaRelatorioTransacoes;
import br.com.cpsinformatica.relatoriosgerenciais.R;
import br.com.cpsinformatica.relatoriosgerenciais.fragments.FragmentTransacoes;
import br.com.cpsinformatica.relatoriosgerenciais.transacoes.RelatorioDeTransacoes;
import br.com.cpsinformatica.relatoriosgerenciais.utils.ConverterMonetario;
import lecho.lib.hellocharts.model.PieChartData;
import lecho.lib.hellocharts.model.SliceValue;
import lecho.lib.hellocharts.util.ChartUtils;
import lecho.lib.hellocharts.view.PieChartView;

/**
 * Created by rodrigo on 11/02/16.
 */
public class MyAdapterTransacoes extends  RecyclerView.Adapter<RecyclerView.ViewHolder> {

    private RelatorioDeTransacoes relatorioDeTransacoes;
    private FragmentTransacoes mFragment;
    private HashMap<String, Long> map;
    private PieChartData data;

    private static final int TYPE_HEADER = 0;
    private static final int TYPE_ITEM = 1;

    // Provide a suitable constructor (depends on the kind of dataset)
    public MyAdapterTransacoes(CarregaRelatorioTransacoes relatorioTransacoes, FragmentTransacoes fragmentTransacoes) {
        this.mFragment = fragmentTransacoes;
        this.relatorioDeTransacoes = relatorioTransacoes.getRelatorioDeTransacoes();
        this.map = relatorioTransacoes.getHasMap();
    }

    public FragmentTransacoes getFragment(){
        return mFragment;
    }

    @Override
    public RecyclerView.ViewHolder onCreateViewHolder(ViewGroup parent, int viewType) {

        if(viewType == TYPE_HEADER){

            View v = LayoutInflater.from(parent.getContext()).inflate(R.layout.recycle_header_transacoes, parent, false);
            HeaderViewHolder hvh = new HeaderViewHolder(v);
            return hvh;

        }else if (viewType == TYPE_ITEM){

            View v = LayoutInflater.from(parent.getContext()).inflate(R.layout.recycle_view_card_transacoes, parent, false);
            ViewHolder vh = new ViewHolder(v);
            return vh;

        }
        return null;
    }

    @Override
    public void onBindViewHolder(RecyclerView.ViewHolder holder, int position) {

        if(holder instanceof HeaderViewHolder) {

            String cabecalho = relatorioDeTransacoes.getCabecalhoTransacoes().getEstabelecimento() + "\n" +
                    relatorioDeTransacoes.getCabecalhoTransacoes().getEndereco() + "\n" +
                    relatorioDeTransacoes.getCabecalhoTransacoes().getCidade() + "\n" +
                    relatorioDeTransacoes.getCabecalhoTransacoes().getPos();
            ((HeaderViewHolder) holder).txtCabecalho.setText(cabecalho);
            ((HeaderViewHolder) holder).txtPeriodo.setText("DE: " + relatorioDeTransacoes.getCabecalhoTransacoes().getDatetime());

            generateData(((HeaderViewHolder) holder));

        }else if (holder instanceof  ViewHolder){

            position -= 1;

            // Obtem elemento do conjunto de dados nesta posição.
            // Substitui o conteúdo da vista com esse elemento.
            ((ViewHolder) holder).txtTipo.setText(relatorioDeTransacoes.getDetalheTransacoesList().get(position).getFormaPag());
            ((ViewHolder) holder).txtForma.setText(relatorioDeTransacoes.getDetalheTransacoesList().get(position).getBandeira());
            ((ViewHolder) holder).txtNsu.setText("NSU: " + relatorioDeTransacoes.getDetalheTransacoesList().get(position).getNsu());
            ((ViewHolder) holder).txtCod.setText("COD AUT: " + relatorioDeTransacoes.getDetalheTransacoesList().get(position).getCodAutorizacao());
            ((ViewHolder) holder).txtStatus.setText(relatorioDeTransacoes.getDetalheTransacoesList().get(position).getStatusTransacao());
            ((ViewHolder) holder).txtDateTime.setText(relatorioDeTransacoes.getDetalheTransacoesList().get(position).getData() + "    " + relatorioDeTransacoes.getDetalheTransacoesList().get(position).getHora());
            ((ViewHolder) holder).txtValor.setText("R$ " + relatorioDeTransacoes.getDetalheTransacoesList().get(position).getValor());
        }
    }

    private void generateData(HeaderViewHolder holder) {

        int count = 0;
        String[] str = new String[map.size()];
        for (String key : map.keySet()){
            str[count] = key;
            count++;
        }

        List<SliceValue> values = new ArrayList<SliceValue>();
        for (int i = 0; i < map.size(); ++i) {

            SliceValue sliceValue = new SliceValue(map.get(str[i]), ChartUtils.pickColor());

            // Altera a string para valor monetário com R$
            Editable editable = ConverterMonetario.convertString(map.get(str[i]).toString());

            sliceValue.setLabel(str[i] + " " + editable.toString());
            sliceValue.getDarkenColor();

            // Altera a cor do gráfico conforme a posção
            switch (str[i]){
                case "CREDITO":
                    sliceValue.setColor(Color.parseColor("#1599DF"));
                    break;
                case "DEBITO":
                    sliceValue.setColor(Color.parseColor("#B0C300"));
                    break;
                case "OUTROS":
                    sliceValue.setColor(Color.parseColor("#E83A03"));
                    break;
                case "VALE REFEICAO":
                    sliceValue.setColor(Color.parseColor("#ED8D00"));
                    break;
                default:
                    sliceValue.setColor(Color.parseColor("#0D3260"));
                    break;
            }

            values.add(sliceValue);
        }

        data = new PieChartData(values);
        data.setHasLabels(true);
        data.setHasLabelsOnlyForSelected(false);
        data.setHasLabelsOutside(false);
        data.setHasCenterCircle(false);
        data.setHasLabels(true);

        holder.pieChart.setPieChartData(data);

        holder.pieChart.setCircleFillRatio(0.7f);
    }

    @Override
    public int getItemViewType (int position) {
        if (isPositionHeader(position))
            return TYPE_HEADER;
        else
            return TYPE_ITEM;
    }

    private boolean isPositionHeader(int position) {
        return position == 0;
    }

    @Override
    public int getItemCount() {
        return relatorioDeTransacoes.getDetalheTransacoesList().size()+1;
    }

    // Provide a reference to the views for each data item
    // Complex data items may need more than one view per item, and
    // you provide access to all the views for a data item in a view holder
    public static class ViewHolder extends RecyclerView.ViewHolder {

        private TextView txtTipo;
        private TextView txtForma;
        private TextView txtNsu;
        private TextView txtCod;
        private TextView txtStatus;
        private TextView txtDateTime;
        private TextView txtValor;

        public ViewHolder(View v) {
            super(v);

            txtTipo = (TextView) v.findViewById(R.id.txtTipo);
            txtForma = (TextView) v.findViewById(R.id.txtForma);
            txtNsu = (TextView) v.findViewById(R.id.txtNsu);
            txtCod = (TextView) v.findViewById(R.id.txtCod);
            txtStatus = (TextView) v.findViewById(R.id.txtStatus);
            txtDateTime = (TextView) v.findViewById(R.id.txtDateTime);
            txtValor = (TextView) v.findViewById(R.id.txtValor);
        }
    }

    // Provide a reference to the views for each data item
    // Complex data items may need more than one view per item, and
    // you provide access to all the views for a data item in a view holder
    public static class HeaderViewHolder extends RecyclerView.ViewHolder {

        private TextView txtCabecalho;
        private TextView txtPeriodo;
        private PieChartView pieChart;

        public HeaderViewHolder(View v) {
            super(v);

            txtCabecalho = (TextView) v.findViewById(R.id.txtCabecalho);
            txtPeriodo = (TextView) v.findViewById(R.id.txtPeriodo);
            pieChart = (PieChartView) v.findViewById(R.id.pieChart);
        }
    }
}
