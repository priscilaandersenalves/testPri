package br.com.cpsinformatica.relatoriosgerenciais.Networking;


import android.graphics.Color;
import android.support.design.widget.Snackbar;
import android.support.v7.widget.RecyclerView;
import android.view.View;

import com.android.volley.DefaultRetryPolicy;
import com.android.volley.Request;
import com.android.volley.RequestQueue;
import com.android.volley.Response;
import com.android.volley.TimeoutError;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.JsonObjectRequest;
import com.android.volley.toolbox.Volley;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;

import br.com.cpsinformatica.relatoriosgerenciais.adapters.MyAdapterTotais;
import br.com.cpsinformatica.relatoriosgerenciais.domains.UsuarioLogado;
import br.com.cpsinformatica.relatoriosgerenciais.enums.MensagemErroEnum;
import br.com.cpsinformatica.relatoriosgerenciais.enums.ParseTotaisEnum;
import br.com.cpsinformatica.relatoriosgerenciais.fragments.FragmentTotais;
import br.com.cpsinformatica.relatoriosgerenciais.totais.CabecalhoTotais;
import br.com.cpsinformatica.relatoriosgerenciais.totais.DetalhePagamentoTotais;
import br.com.cpsinformatica.relatoriosgerenciais.totais.FooterRecorrencia;
import br.com.cpsinformatica.relatoriosgerenciais.totais.FooterTotalGeral;
import br.com.cpsinformatica.relatoriosgerenciais.totais.FormasPagamentoTotais;
import br.com.cpsinformatica.relatoriosgerenciais.totais.RelatorioDeTotais;
import br.com.cpsinformatica.relatoriosgerenciais.utils.MyAnimation;
import br.com.cpsinformatica.relatoriosgerenciais.utils.Preferences;
import br.com.cpsinformatica.relatoriosgerenciais.utils.URL;

/**
 * Created by rodrigo on 12/02/16.
 */
public class CarregaRelatorioTotais {

    private FragmentTotais mFragmentTotais;
    private RecyclerView mRecyclerView;
    private RelatorioDeTotais relatorioDeTotais;
    private HashMap<String, Long> map;
    private static Snackbar snackbar;

    private static String TAG = CarregaRelatorioTotais.class.getSimpleName();

    public CarregaRelatorioTotais(FragmentTotais mFragmentTotais){
        this.mFragmentTotais = mFragmentTotais;
        this.mRecyclerView = mFragmentTotais.getRecyclerView();
        this.map = new HashMap<>();
    }

    public void request(final String dataIni, final String horaIni, final String dataFim, final String horaFim){

        // Esconde SnackBar se estiver visível
        if(snackbar != null && snackbar.getView().getVisibility() == View.VISIBLE){
            snackbar.dismiss();
        }

        // Exibe icone de Progress na tela
        mFragmentTotais.getProgressBar().setVisibility(View.VISIBLE);

        // Trata o retorno do webservice de totais
        Response.Listener<JSONObject> successListener = new Response.Listener<JSONObject>() {
            @Override
            public void onResponse(JSONObject jsonObject) {

                try {

                    List<FormasPagamentoTotais> formasPagamentosList = new ArrayList<>();

                    relatorioDeTotais = new RelatorioDeTotais();
                    relatorioDeTotais.setStatus(jsonObject.getBoolean(ParseTotaisEnum.STATUS.getText()));
                    relatorioDeTotais.setMensagem(jsonObject.getString(ParseTotaisEnum.MENSAGEM.getText()));

                    System.out.println(TAG + " " + jsonObject.getString(ParseTotaisEnum.MENSAGEM.getText()));

                    if (relatorioDeTotais.isStatus()){

                        JSONObject arrayCabecalho = jsonObject.getJSONObject(ParseTotaisEnum.CABECALHO.getText());

                        CabecalhoTotais cabecalhoTotais = new CabecalhoTotais();
                        cabecalhoTotais.setEstabelecimento(arrayCabecalho.getString(ParseTotaisEnum.ESTABELECIMENTO.getText()));
                        cabecalhoTotais.setEndereco(arrayCabecalho.getString(ParseTotaisEnum.ENDERECO.getText()));
                        cabecalhoTotais.setCidade(arrayCabecalho.getString(ParseTotaisEnum.CIDADE.getText()));
                        cabecalhoTotais.setPos(arrayCabecalho.getInt(ParseTotaisEnum.POS.getText()));
                        cabecalhoTotais.setDatetime(arrayCabecalho.getString(ParseTotaisEnum.DATETIME.getText()));

                        relatorioDeTotais.setCabecalhoTotais(cabecalhoTotais);

                        JSONObject objectFormasPagamento = jsonObject.getJSONObject(ParseTotaisEnum.FORMAS_PAGAMENTO.getText());

                        Iterator iteratorFormasPGTO = objectFormasPagamento.keys();
                        while(iteratorFormasPGTO.hasNext()) {

                            String forma = (String)iteratorFormasPGTO.next();

                            if(!map.containsKey(forma)){
                                map.put(forma, Long.valueOf(0));
                            }

                            FormasPagamentoTotais formasPagamento = new FormasPagamentoTotais();
                            formasPagamento.setFormaPagamento(forma);
                            formasPagamentosList.add(formasPagamento);

                            JSONArray bandeiras = objectFormasPagamento.getJSONArray(forma);

                            List<DetalhePagamentoTotais> detalhePagamentoList = new ArrayList<>();

                            int length = bandeiras.length();
                            for (int i = 0; i < length; i++) {

                                JSONObject objectBandeiras = (JSONObject) bandeiras.get(i);

                                DetalhePagamentoTotais detalhePagamento = new DetalhePagamentoTotais();
                                detalhePagamento.setBandeira(objectBandeiras.getString(ParseTotaisEnum.BANDEIRA.getText()));
                                detalhePagamento.setQuantidade(objectBandeiras.getInt(ParseTotaisEnum.QUANTIDADE.getText()));
                                detalhePagamento.setValor(objectBandeiras.getString(ParseTotaisEnum.VALOR.getText()));
                                detalhePagamentoList.add(detalhePagamento);
                                formasPagamento.setDetalhePagamentoList(detalhePagamentoList);


                                /**
                                 *  Esse código é responsável por
                                 *  capturar as informações do gráfico
                                 *  do cabeçalho
                                 */
                                if(detalhePagamento.getBandeira().contains("TOTAL")) {

                                    String valuePgto = detalhePagamento.getValor().replaceAll("\\.", "").replace(",", "");
                                    long value = Long.parseLong(valuePgto);
                                    long longMap = map.get(forma);

                                    long result = longMap + value;

                                    map.put(forma, result);
                                }
                            }
                        }

                        relatorioDeTotais.setFormasPagamentosList(formasPagamentosList);

                        // Cria o objeto que preenche o rodapé de TOTAIS
                        JSONObject arrayTotalGeral = jsonObject.getJSONObject(ParseTotaisEnum.TOTAL_GERAL_UPP.getText());
                        FooterTotalGeral footerTotalGeral = new FooterTotalGeral();
                        footerTotalGeral.setQtdCancel(arrayTotalGeral.getInt(ParseTotaisEnum.QTDE_CANCEL.getText()));
                        footerTotalGeral.setTotalCancel(arrayTotalGeral.getString(ParseTotaisEnum.TOTAL_CANCEL.getText()));
                        footerTotalGeral.setQtdGeral(arrayTotalGeral.getInt(ParseTotaisEnum.QTDE_GERAL.getText()));
                        footerTotalGeral.setTotalGeral(arrayTotalGeral.getString(ParseTotaisEnum.TOTAL_GERAL.getText()));
                        relatorioDeTotais.setFooterTotalGeral(footerTotalGeral);

                        // Cria o objeto que preenche o rodapé de RECORRENCIA DE CLIENTES
                        JSONObject arrayRecorrencia = jsonObject.getJSONObject("RECORRENCIA_CLIENTE");
                        FooterRecorrencia footerRecorrencia = new FooterRecorrencia();
                        footerRecorrencia.setUmaCompra(arrayRecorrencia.getInt("umaCompra"));
                        footerRecorrencia.setDuasCompras(arrayRecorrencia.getInt("duasCompras"));
                        footerRecorrencia.setTresOuMaisCompras(arrayRecorrencia.getInt("tresOuMaisCompras"));
                        relatorioDeTotais.setFooterRecorrencia(footerRecorrencia);

                        // specify an adapter (see also next example)
                        MyAdapterTotais mAdapter = new MyAdapterTotais(CarregaRelatorioTotais.this, mFragmentTotais);
                        mRecyclerView.setAdapter(mAdapter);
                        MyAnimation.animationFadeIn(mRecyclerView);

                    }else {

                        mRecyclerView.setAdapter(null);
                        snackMessageActionTENTAR(relatorioDeTotais.getMensagem(), dataIni, horaIni, dataFim, horaFim);
                    }

                } catch (JSONException e) {
                    mRecyclerView.setAdapter(null);
                    Snackbar snackbar = Snackbar.make(mFragmentTotais.getActivity().findViewById(android.R.id.content), e.getMessage(), Snackbar.LENGTH_LONG);
                    snackbar.show();
                }

                mFragmentTotais.getProgressBar().setVisibility(View.INVISIBLE);
            }
        };

        Response.ErrorListener errorListener = new Response.ErrorListener() {
            @Override
            public void onErrorResponse(VolleyError volleyError) {

                if (volleyError.networkResponse == null) {
                    if (volleyError.getClass().equals(TimeoutError.class)) {
                        snackMessageActionTENTAR(MensagemErroEnum.TEMPO_EXCEDIDO.getText(), dataIni, horaIni, dataFim, horaFim);
                    }else {
                        snackMessageActionTENTAR(MensagemErroEnum.SEM_CONEXAO.getText(), dataIni, horaIni, dataFim, horaFim);
                    }
                }
                mFragmentTotais.getProgressBar().setVisibility(View.INVISIBLE);
            }
        };

        // Efetua a requisição do webservice
        String url = String.format(URL.REL_TOTAIS, Preferences.getIP(mFragmentTotais.getActivity()), dataIni, horaIni, dataFim, horaFim, UsuarioLogado.getUsuario());

        System.out.println(url);

        JsonObjectRequest request = new JsonObjectRequest(Request.Method.GET, url, successListener, errorListener);
        request.setRetryPolicy(new DefaultRetryPolicy(
                15000,
                DefaultRetryPolicy.DEFAULT_MAX_RETRIES,
                DefaultRetryPolicy.DEFAULT_BACKOFF_MULT));
        RequestQueue mQueue = Volley.newRequestQueue(mFragmentTotais.getActivity());
        mQueue.add(request);

    }

    public RelatorioDeTotais getRelatorioDeTotais(){
        return relatorioDeTotais;
    }

    private void snackMessageActionTENTAR(String mensagem, final String dataIni, final String horaIni, final String dataFim, final String horaFim){

        snackbar = Snackbar.make(mFragmentTotais.getActivity().findViewById(android.R.id.content), mensagem, Snackbar.LENGTH_INDEFINITE)
                .setAction(MensagemErroEnum.TENTAR.getText(), new View.OnClickListener() {
                    @Override
                    public void onClick(View v) {

                        // Callback recursivo da requisição de pagamento
                        mFragmentTotais.getProgressBar().setVisibility(View.VISIBLE);
                        CarregaRelatorioTotais.this.request(dataIni, horaIni, dataFim, horaFim);
                    }
                });
        snackbar.setActionTextColor(Color.parseColor("#008ec2"));
        snackbar.show();
    }

    public HashMap<String, Long> getHasMap(){
        return map;
    }

    public static void snackbarDismiss(){
        snackbar.dismiss();
    }

    public static Snackbar getSnackbar(){
        return snackbar;
    }
}