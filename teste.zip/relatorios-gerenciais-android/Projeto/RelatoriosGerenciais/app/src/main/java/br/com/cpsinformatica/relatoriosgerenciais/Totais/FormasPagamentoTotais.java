package br.com.cpsinformatica.relatoriosgerenciais.totais;

import java.util.List;

/**
 * Created by rodrigo on 16/02/16.
 */
public class FormasPagamentoTotais {

    private String formaPagamento;
    private List<DetalhePagamentoTotais> detalhePagamentoList;

    public String getFormaPagamento() {
        return formaPagamento;
    }

    public void setFormaPagamento(String formaPagamento) {
        this.formaPagamento = formaPagamento;
    }

    public List<DetalhePagamentoTotais> getDetalhePagamentoList() {
        return detalhePagamentoList;
    }

    public void setDetalhePagamentoList(List<DetalhePagamentoTotais> detalhePagamentoList) {
        this.detalhePagamentoList = detalhePagamentoList;
    }
}
