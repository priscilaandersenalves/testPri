package br.com.cpsinformatica.relatoriosgerenciais.service.impl;

import android.app.Activity;
import android.app.ProgressDialog;

import com.android.volley.DefaultRetryPolicy;
import com.android.volley.Request;
import com.android.volley.RequestQueue;
import com.android.volley.Response;
import com.android.volley.TimeoutError;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.JsonObjectRequest;
import com.android.volley.toolbox.Volley;

import org.json.JSONException;
import org.json.JSONObject;

import br.com.cpsinformatica.relatoriosgerenciais.domains.Login;
import br.com.cpsinformatica.relatoriosgerenciais.R;
import br.com.cpsinformatica.relatoriosgerenciais.utils.Preferences;
import br.com.cpsinformatica.relatoriosgerenciais.utils.URL;
import br.com.cpsinformatica.relatoriosgerenciais.enums.LoginEnum;
import br.com.cpsinformatica.relatoriosgerenciais.enums.MensagemErroEnum;
import br.com.cpsinformatica.relatoriosgerenciais.service.LoginService;
import br.com.cpsinformatica.relatoriosgerenciais.domains.UsuarioLogado;

/**
 * Created by rodrigo on 22/02/16.
 */
public class LoginServiceImpl implements LoginService {

    private Activity activity;
    private String usuario;
    private String senha;
    private boolean isChecked;
    public ProgressDialog progressDialog;

    public LoginServiceImpl(Activity activity){
        this.activity = activity;
    }

    @Override
    public void efetuarLogin(String usuario, String senha) {
        this.usuario = usuario;
        this.senha = senha;

        progressDialog = ProgressDialog.show(activity, activity.getString(R.string.aguarde), activity.getString(R.string.buscando_usuario), false, false);

        if(usuario.replace(" ","").equals("") || senha.replace(" ","").equals("")){
            onError(activity.getString(R.string.preencha_campos));
            return;
        }

        String url = String.format(URL.LOGIN, Preferences.getIP(activity), usuario, senha);
        System.out.println(url);
        JsonObjectRequest request = new JsonObjectRequest(Request.Method.GET, url, getSuccessListener(), getErrorListener());
        request.setRetryPolicy(new DefaultRetryPolicy(
                15000,
                DefaultRetryPolicy.DEFAULT_MAX_RETRIES,
                DefaultRetryPolicy.DEFAULT_BACKOFF_MULT));
        RequestQueue mQueue = Volley.newRequestQueue(activity);
        mQueue.add(request);
    }

    @Override
    public void onSuccess(Login login) {
        if(progressDialog != null)
            progressDialog.dismiss();
    }

    @Override
    public void onError(String messageError) {
        if(progressDialog != null)
            progressDialog.dismiss();
    }

    private Response.Listener<JSONObject> getSuccessListener(){
        Response.Listener<JSONObject> successListener = new Response.Listener<JSONObject>() {
            @Override
            public void onResponse(JSONObject jsonObject) {

                try {

                    Login login = new Login();
                    login.setStatus(jsonObject.getBoolean(LoginEnum.STATUS.getText()));
                    login.setMensagem(jsonObject.getString(LoginEnum.MENSAGEM.getText()));

                    // Salva usuario no disposivtivo
                    if(isChecked)
                        Preferences.salvaUsuario(getActivity(), getUsuario());

                    // Salva usuario na variavel Global
                    UsuarioLogado.setUsuario(getUsuario());

                    if(login.isStatus())
                        onSuccess(login);
                    else
                        onError(login.getMensagem());

                } catch (JSONException e) {
                    onError(e.getMessage());
                }
            }
        };
        return successListener;
    }

    private Response.ErrorListener getErrorListener(){
        Response.ErrorListener errorListener = new Response.ErrorListener() {
            @Override
            public void onErrorResponse(VolleyError volleyError) {

                if (volleyError.networkResponse == null) {
                    if (volleyError.getClass().equals(TimeoutError.class)) {
                        onError(MensagemErroEnum.TEMPO_EXCEDIDO.getText());
                    }else if(volleyError.getMessage().contains("host")){
                        onError(MensagemErroEnum.HOST.getText());
                    }else {
                        onError(MensagemErroEnum.SEM_CONEXAO.getText());
                    }
                }else {
                    onError(volleyError.getMessage());
                }
            }
        };
        return errorListener;
    }

    public Activity getActivity(){
        return activity;
    }

    public String getUsuario(){
        return usuario;
    }

    public void setChecked(boolean isChecked){
        this.isChecked = isChecked;
    }
}