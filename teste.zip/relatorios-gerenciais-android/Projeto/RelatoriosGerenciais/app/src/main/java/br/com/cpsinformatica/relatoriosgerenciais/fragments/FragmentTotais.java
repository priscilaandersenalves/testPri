package br.com.cpsinformatica.relatoriosgerenciais.fragments;

import android.os.Bundle;
import android.support.v4.app.Fragment;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ProgressBar;

import br.com.cpsinformatica.relatoriosgerenciais.Networking.CarregaRelatorioTotais;
import br.com.cpsinformatica.relatoriosgerenciais.R;
import br.com.cpsinformatica.relatoriosgerenciais.domains.DateTimeBusca;

/**
 * Created by rodrigo on 05/02/16.
 */
public class FragmentTotais extends Fragment{

    private RecyclerView mRecyclerView;
    private ProgressBar progressBar;

    /**
     * The fragment argument representing the section number for this
     * fragment.
     */
    private static final String ARG_SECTION_NUMBER = "section_number";

    public static FragmentTotais newInstance(int sectionNumber) {

        FragmentTotais fragment = new FragmentTotais();
        Bundle args = new Bundle();
        args.putInt(ARG_SECTION_NUMBER, sectionNumber);
        fragment.setArguments(args);

        return fragment;
    }

    public FragmentTotais() {
    }

    /**
     * Metodo responsável por criar e
     * tratar as view do fragmento TOTAIS
     * @param inflater
     * @param container
     * @param savedInstanceState
     * @return
     */
    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        View rootView = inflater.inflate(R.layout.fragment_totais, container, false);

        progressBar = (ProgressBar) rootView.findViewById(R.id.progressBar);

        mRecyclerView = (RecyclerView) rootView.findViewById(R.id.rvTotais);
        mRecyclerView.setHasFixedSize(true);

        LinearLayoutManager layoutManager = new LinearLayoutManager(getActivity());
        layoutManager.setOrientation(LinearLayoutManager.VERTICAL);
        mRecyclerView.setLayoutManager(layoutManager);

        // Chama o webservice que carrega a lista de TOTAIS
        CarregaRelatorioTotais carregaRelatorioTotais = new CarregaRelatorioTotais(this);
        carregaRelatorioTotais.request(DateTimeBusca.getDataIni(), DateTimeBusca.getHoraIni(), DateTimeBusca.getDataFim(), DateTimeBusca.getHoraFim());

        return rootView;
    }

    /**
     * Metodo responsável por
     * retornar o progressBar
     * @return
     */
    public ProgressBar getProgressBar(){
        return progressBar;
    }

    /**
     * Metodo responsável por
     * retornar o RecycleView
     * @return
     */
    public RecyclerView getRecyclerView(){
        return mRecyclerView;
    }
}