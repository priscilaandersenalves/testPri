package br.com.cpsinformatica.relatoriosgerenciais.utils;

import android.app.Activity;
import android.content.Context;
import android.content.SharedPreferences;

/**
 * Created by rodrigo on 23/02/16.
 */
public class Preferences {

    private static String dataIni;
    private static String dataFin;
    private static String horaIni;
    private static String horaFin;

    public static void salvaUsuario(Activity activity, String usuario){
        SharedPreferences sharedPref = activity.getSharedPreferences("AUTENTICATION", Context.MODE_PRIVATE);
        SharedPreferences.Editor editor = sharedPref.edit();
        editor.putString("USUARIO", usuario);
        editor.commit();
    }

    public static String getUsuario(Activity activity){
        SharedPreferences sharedPref = activity.getSharedPreferences("AUTENTICATION", Context.MODE_PRIVATE);
        return sharedPref.getString("USUARIO", "");
    }

    public static void removeUsuario(Activity activity){
        SharedPreferences sharedPref = activity.getSharedPreferences("AUTENTICATION", Context.MODE_PRIVATE);
        SharedPreferences.Editor editor = sharedPref.edit();
        editor.clear();
        editor.commit();
    }

    public static void salvaIP(Activity activity, String ip){
        SharedPreferences sharedPref = activity.getSharedPreferences("CONFIGURACAO", Context.MODE_PRIVATE);
        SharedPreferences.Editor editor = sharedPref.edit();
        editor.putString("IP", ip);
        editor.commit();
    }

    public static String getIP(Activity activity){
        SharedPreferences sharedPref = activity.getSharedPreferences("CONFIGURACAO", Context.MODE_PRIVATE);
        return sharedPref.getString("IP", "");
    }

    public static String[] getDataHoraPersonalizada(Activity activity) {

        String[] strValues = new String[4];
        SharedPreferences sharedPref = activity.getSharedPreferences("DATETIME", Context.MODE_PRIVATE);
        strValues[0] = sharedPref.getString("DATA_INI", "");
        strValues[1] = sharedPref.getString("HORA_INI", "");
        strValues[2] = sharedPref.getString("DATA_FIM", "");
        strValues[3] = sharedPref.getString("HORA_FIM", "");

        return strValues;
    }

    public static void savarDataHoraPersonalizada(Activity activity, String dataIni, String horaIni, String dataFim, String horaFim) {
        SharedPreferences sharedPref = activity.getSharedPreferences("DATETIME", Context.MODE_PRIVATE);
        SharedPreferences.Editor editor = sharedPref.edit();
        editor.putString("DATA_INI", dataIni);
        editor.putString("HORA_INI", horaIni);
        editor.putString("DATA_FIM", dataFim);
        editor.putString("HORA_FIM", horaFim);
        editor.commit();
    }

    public static void limparDataHoraPersonalizada(Activity activity) {
        SharedPreferences sharedPref = activity.getSharedPreferences("DATETIME", Context.MODE_PRIVATE);
        SharedPreferences.Editor editor = sharedPref.edit();
        editor.clear();
        editor.commit();
    }
}
