package br.com.cpsinformatica.relatoriosgerenciais.transacoes;

import java.util.List;

/**
 * Created by rodrigo on 17/02/16.
 */
public class RelatorioDeTransacoes {

    private boolean status;
    private String mensagem;
    private CabecalhoTransacoes cabecalhoTransacoes;
    private List<DetalheTransacoes> detalheTransacoesList;

    public boolean isStatus() {
        return status;
    }

    public void setStatus(boolean status) {
        this.status = status;
    }

    public String getMensagem() {
        return mensagem;
    }

    public void setMensagem(String mensagem) {
        this.mensagem = mensagem;
    }

    public CabecalhoTransacoes getCabecalhoTransacoes() {
        return cabecalhoTransacoes;
    }

    public void setCabecalhoTransacoes(CabecalhoTransacoes cabecalhoTotais) {
        this.cabecalhoTransacoes = cabecalhoTotais;
    }

    public List<DetalheTransacoes> getDetalheTransacoesList() {
        return detalheTransacoesList;
    }

    public void setDetalheTransacoesList(List<DetalheTransacoes> detalheTransacoesList) {
        this.detalheTransacoesList = detalheTransacoesList;
    }
}
