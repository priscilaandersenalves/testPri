package br.com.cpsinformatica.relatoriosgerenciais.detalhado;

import java.util.List;

/**
 * Created by rodrigo on 16/02/16.
 */
public class ProdutosDetalhado {

    private String produto;
    private List<ProdutosDetalhado> produtosDetalhadoList;

    public String getProduto() {
        return produto;
    }

    public void setProduto(String produto) {
        this.produto = produto;
    }

    public List<ProdutosDetalhado> getProdutosDetalhadoList() {
        return produtosDetalhadoList;
    }

    public void setProdutosDetalhadoList(List<ProdutosDetalhado> produtosDetalhadoList) {
        this.produtosDetalhadoList = produtosDetalhadoList;
    }
}
