
package br.com.cpsinformatica.relatoriosgerenciais.jsonparse;

import javax.annotation.Generated;
import javax.validation.Valid;
import com.google.gson.annotations.Expose;
import com.google.gson.annotations.SerializedName;

@Generated("org.jsonschema2pojo")
public class FORMASPAGAMENTO {

    @SerializedName("DEBITO")
    @Expose
    @Valid
    private br.com.cpsinformatica.relatoriosgerenciais.jsonparse.DEBITO DEBITO;
    @SerializedName("CREDITO")
    @Expose
    @Valid
    private br.com.cpsinformatica.relatoriosgerenciais.jsonparse.CREDITO CREDITO;

    /**
     * 
     * @return
     *     The DEBITO
     */
    public br.com.cpsinformatica.relatoriosgerenciais.jsonparse.DEBITO getDEBITO() {
        return DEBITO;
    }

    /**
     * 
     * @param DEBITO
     *     The DEBITO
     */
    public void setDEBITO(br.com.cpsinformatica.relatoriosgerenciais.jsonparse.DEBITO DEBITO) {
        this.DEBITO = DEBITO;
    }

    /**
     * 
     * @return
     *     The CREDITO
     */
    public br.com.cpsinformatica.relatoriosgerenciais.jsonparse.CREDITO getCREDITO() {
        return CREDITO;
    }

    /**
     * 
     * @param CREDITO
     *     The CREDITO
     */
    public void setCREDITO(br.com.cpsinformatica.relatoriosgerenciais.jsonparse.CREDITO CREDITO) {
        this.CREDITO = CREDITO;
    }

}
