package br.com.cpsinformatica.relatoriosgerenciais.totais;

/**
 * Created by rodrigo on 16/02/16.
 */
public class DetalhePagamentoTotais {

    private String bandeira;
    private int quantidade;
    private String valor;

    public String getBandeira() {
        return bandeira;
    }

    public void setBandeira(String bandeira) {
        this.bandeira = bandeira;
    }

    public int getQuantidade() {
        return quantidade;
    }

    public void setQuantidade(int quantidade) {
        this.quantidade = quantidade;
    }

    public String getValor() {
        return valor;
    }

    public void setValor(String valor) {
        this.valor = valor;
    }
}