package br.com.cpsinformatica.relatoriosgerenciais.enums;

/**
 * Created by rodrigo on 17/02/16.
 */
public enum ParseDetalhadoEnum {

    STATUS("status"),
    MENSAGEM("mensagem"),
    CABECALHO("CABECALHO"),
    ESTABELECIMENTO("estabelecimento"),
    ENDERECO("endereco"),
    CIDADE("cidade"),
    POS("pos"),
    DATETIME("datetime"),
    FORMAS_PAGAMENTO("FORMAS_PAGAMENTO"),
    NSU("nsu"),
    DATA("data"),
    HORA("hora"),
    STATUS_TRANSAC("statusTransacao"),
    VALOR("valor"),
    BANDEIRA("bandeira"),
    QUANTIDADE("qtdePag");

    private String valor;

    ParseDetalhadoEnum(String str){
        valor = str;
    }

    public String getText(){
        return valor;
    }
}
