package br.com.cpsinformatica.relatoriosgerenciais.domains;

import android.app.Activity;
import android.content.Intent;

import br.com.cpsinformatica.relatoriosgerenciais.activitys.MainActivity;
import br.com.cpsinformatica.relatoriosgerenciais.service.impl.LoginServiceImpl;
import br.com.cpsinformatica.relatoriosgerenciais.utils.Mensagens;

/**
 * Created by rodrigo on 22/02/16.
 */
public class Logar extends LoginServiceImpl {

    public Logar(Activity activity) {
        super(activity);
    }

    @Override
    public void onSuccess(Login login) {
        super.onSuccess(login);
        abreMainActivity();
    }

    @Override
    public void onError(String messageError) {
        super.onError(messageError);
        Mensagens.mensagemSnackLong(getActivity(), messageError);
    }

    public void abreMainActivity(){

        Intent intent = new Intent(getActivity(), MainActivity.class);
        getActivity().startActivity(intent);

        getActivity().finish();
    }
}
