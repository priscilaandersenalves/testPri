
package br.com.cpsinformatica.relatoriosgerenciais.jsonparse;

import javax.annotation.Generated;
import com.google.gson.annotations.Expose;
import com.google.gson.annotations.SerializedName;

@Generated("org.jsonschema2pojo")
public class TOTALVISA {

    @SerializedName("bandeira")
    @Expose
    private String bandeira;
    @SerializedName("valor")
    @Expose
    private String valor;
    @SerializedName("qtdePag")
    @Expose
    private Integer qtdePag;

    /**
     * 
     * @return
     *     The bandeira
     */
    public String getBandeira() {
        return bandeira;
    }

    /**
     * 
     * @param bandeira
     *     The bandeira
     */
    public void setBandeira(String bandeira) {
        this.bandeira = bandeira;
    }

    /**
     * 
     * @return
     *     The valor
     */
    public String getValor() {
        return valor;
    }

    /**
     * 
     * @param valor
     *     The valor
     */
    public void setValor(String valor) {
        this.valor = valor;
    }

    /**
     * 
     * @return
     *     The qtdePag
     */
    public Integer getQtdePag() {
        return qtdePag;
    }

    /**
     * 
     * @param qtdePag
     *     The qtdePag
     */
    public void setQtdePag(Integer qtdePag) {
        this.qtdePag = qtdePag;
    }

}
