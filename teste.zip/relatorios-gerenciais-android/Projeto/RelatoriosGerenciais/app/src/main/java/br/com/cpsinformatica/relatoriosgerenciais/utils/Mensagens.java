package br.com.cpsinformatica.relatoriosgerenciais.utils;

import android.app.Activity;
import android.graphics.Color;
import android.support.design.widget.Snackbar;
import android.view.View;
import android.widget.TextView;
import android.widget.Toast;

/**
 * Created by rodrigo on 22/02/16.
 */
public class Mensagens {

    public static void mensagemSnackLong(Activity activity, String msg){
        Snackbar.make(activity.findViewById(android.R.id.content), msg, Snackbar.LENGTH_LONG)
                .setAction("Action", null).show();
    }

    public static void mensagemSnackButton(final Activity activity, String action, String mensagem) {

        Snackbar snackbar = Snackbar.make(activity.findViewById(android.R.id.content), mensagem, Snackbar.LENGTH_INDEFINITE)
                .setAction(action, new View.OnClickListener() {
                    @Override
                    public void onClick(View v) {

                        Toast.makeText(activity, "Clicou", Toast.LENGTH_LONG).show();

                    }
                });
        snackbar.setActionTextColor(Color.YELLOW);
        snackbar.show();
    }
}
