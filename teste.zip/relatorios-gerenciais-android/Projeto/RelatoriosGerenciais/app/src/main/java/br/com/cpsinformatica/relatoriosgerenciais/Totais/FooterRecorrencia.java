package br.com.cpsinformatica.relatoriosgerenciais.totais;

/**
 * Created by rodrigo on 18/02/16.
 */
public class FooterRecorrencia {

    private int umaCompra;
    private int duasCompras;
    private int tresOuMaisCompras;

    public int getUmaCompra() {
        return umaCompra;
    }

    public void setUmaCompra(int umaCompra) {
        this.umaCompra = umaCompra;
    }

    public int getDuasCompras() {
        return duasCompras;
    }

    public void setDuasCompras(int duasCompras) {
        this.duasCompras = duasCompras;
    }

    public int getTresOuMaisCompras() {
        return tresOuMaisCompras;
    }

    public void setTresOuMaisCompras(int tresOuMaisCompras) {
        this.tresOuMaisCompras = tresOuMaisCompras;
    }
}
