package br.com.cpsinformatica.relatoriosgerenciais.totais;

import java.util.List;

/**
 * Created by rodrigo on 17/02/16.
 */
public class RelatorioDeTotais {

    private boolean status;
    private String mensagem;
    private CabecalhoTotais cabecalhoTotais;
    private List<FormasPagamentoTotais> formasPagamentosList;
    private FooterTotalGeral footerTotalGeral;
    private FooterRecorrencia footerRecorrencia;

    public boolean isStatus() {
        return status;
    }

    public void setStatus(boolean status) {
        this.status = status;
    }

    public String getMensagem() {
        return mensagem;
    }

    public void setMensagem(String mensagem) {
        this.mensagem = mensagem;
    }

    public CabecalhoTotais getCabecalhoTotais() {
        return cabecalhoTotais;
    }

    public void setCabecalhoTotais(CabecalhoTotais cabecalhoTotais) {
        this.cabecalhoTotais = cabecalhoTotais;
    }

    public List<FormasPagamentoTotais> getFormasPagamentosList() {
        return formasPagamentosList;
    }

    public void setFormasPagamentosList(List<FormasPagamentoTotais> formasPagamentosList) {
        this.formasPagamentosList = formasPagamentosList;
    }

    public FooterTotalGeral getFooterTotalGeral() {
        return footerTotalGeral;
    }

    public void setFooterTotalGeral(FooterTotalGeral footerTotalGeral) {
        this.footerTotalGeral = footerTotalGeral;
    }

    public FooterRecorrencia getFooterRecorrencia() {
        return footerRecorrencia;
    }

    public void setFooterRecorrencia(FooterRecorrencia footerRecorrencia) {
        this.footerRecorrencia = footerRecorrencia;
    }
}
