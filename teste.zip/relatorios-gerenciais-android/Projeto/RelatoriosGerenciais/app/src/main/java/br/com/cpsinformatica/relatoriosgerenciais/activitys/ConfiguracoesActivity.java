package br.com.cpsinformatica.relatoriosgerenciais.activitys;

import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.support.v7.widget.Toolbar;
import android.view.MenuItem;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;

import br.com.cpsinformatica.relatoriosgerenciais.R;
import br.com.cpsinformatica.relatoriosgerenciais.utils.Preferences;

public class ConfiguracoesActivity extends AppCompatActivity {

    Button buttonSalvar;
    EditText inputIp;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_configuracoes);
        Toolbar toolbar = (Toolbar) findViewById(R.id.toolbar);
        setSupportActionBar(toolbar);

        getSupportActionBar().setDisplayHomeAsUpEnabled(true);
        getSupportActionBar().setDisplayShowHomeEnabled(true);

        initElements();

        inputIp.setText(Preferences.getIP(this));

        buttonSalvar.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Preferences.salvaIP(ConfiguracoesActivity.this, inputIp.getText().toString());
                finish();
            }
        });
    }

    private void initElements(){
        buttonSalvar = (Button) findViewById(R.id.buttonSalvar);
        inputIp = (EditText) findViewById(R.id.inputIp);
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {

        onBackPressed();

        return super.onOptionsItemSelected(item);
    }
}
