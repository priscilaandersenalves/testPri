
package br.com.cpsinformatica.relatoriosgerenciais.jsonparse;

import javax.annotation.Generated;
import com.google.gson.annotations.Expose;
import com.google.gson.annotations.SerializedName;

@Generated("org.jsonschema2pojo")
public class CABECALHO {

    @SerializedName("estabelecimento")
    @Expose
    private String estabelecimento;
    @SerializedName("endereco")
    @Expose
    private String endereco;
    @SerializedName("cidade")
    @Expose
    private String cidade;
    @SerializedName("pos")
    @Expose
    private Integer pos;
    @SerializedName("datetime")
    @Expose
    private String datetime;

    /**
     * 
     * @return
     *     The estabelecimento
     */
    public String getEstabelecimento() {
        return estabelecimento;
    }

    /**
     * 
     * @param estabelecimento
     *     The estabelecimento
     */
    public void setEstabelecimento(String estabelecimento) {
        this.estabelecimento = estabelecimento;
    }

    /**
     * 
     * @return
     *     The endereco
     */
    public String getEndereco() {
        return endereco;
    }

    /**
     * 
     * @param endereco
     *     The endereco
     */
    public void setEndereco(String endereco) {
        this.endereco = endereco;
    }

    /**
     * 
     * @return
     *     The cidade
     */
    public String getCidade() {
        return cidade;
    }

    /**
     * 
     * @param cidade
     *     The cidade
     */
    public void setCidade(String cidade) {
        this.cidade = cidade;
    }

    /**
     * 
     * @return
     *     The pos
     */
    public Integer getPos() {
        return pos;
    }

    /**
     * 
     * @param pos
     *     The pos
     */
    public void setPos(Integer pos) {
        this.pos = pos;
    }

    /**
     * 
     * @return
     *     The datetime
     */
    public String getDatetime() {
        return datetime;
    }

    /**
     * 
     * @param datetime
     *     The datetime
     */
    public void setDatetime(String datetime) {
        this.datetime = datetime;
    }

}
