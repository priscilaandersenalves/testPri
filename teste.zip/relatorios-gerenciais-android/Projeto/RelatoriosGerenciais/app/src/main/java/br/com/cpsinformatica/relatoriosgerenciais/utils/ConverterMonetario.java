package br.com.cpsinformatica.relatoriosgerenciais.utils;

import android.text.Editable;
import android.text.SpannableStringBuilder;

import java.text.NumberFormat;

/**
 * Created by rodrigo on 21/03/16.
 */
public class ConverterMonetario {

    public static Editable convertString(String value){

        // Converte valor da string para monetário $$
        Editable editable = new SpannableStringBuilder(value);
        String digits = editable.toString().replaceAll("\\D", "");
        NumberFormat nf = NumberFormat.getCurrencyInstance();
        try {
            String formatted = nf.format(Double.parseDouble(digits) / 100);
            editable.replace(0, editable.length(), formatted);
        } catch (NumberFormatException nfe) {
            editable.clear();
        }

        return editable;
    }
}
