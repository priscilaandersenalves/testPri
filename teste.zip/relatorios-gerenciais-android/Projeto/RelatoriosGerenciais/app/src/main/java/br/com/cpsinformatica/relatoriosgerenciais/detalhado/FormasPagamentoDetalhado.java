package br.com.cpsinformatica.relatoriosgerenciais.detalhado;

import java.util.List;

import br.com.cpsinformatica.relatoriosgerenciais.totais.DetalhePagamentoTotais;

/**
 * Created by rodrigo on 16/02/16.
 */
public class FormasPagamentoDetalhado {

    private String formaPagamento;
    private List<DetalhePagamentoDetalhado> detalhePagamentoList;

    public String getFormaPagamento() {
        return formaPagamento;
    }

    public void setFormaPagamento(String formaPagamento) {
        this.formaPagamento = formaPagamento;
    }

    public List<DetalhePagamentoDetalhado> getDetalhePagamentoList() {
        return detalhePagamentoList;
    }

    public void setDetalhePagamentoList(List<DetalhePagamentoDetalhado> detalhePagamentoList) {
        this.detalhePagamentoList = detalhePagamentoList;
    }
}
