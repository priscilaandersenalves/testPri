package br.com.cpsinformatica.relatoriosgerenciais.service;

import br.com.cpsinformatica.relatoriosgerenciais.domains.Login;

/**
 * Created by rodrigo on 22/02/16.
 */
public interface LoginService {

    public void efetuarLogin(String usuario, String senha);
    public void onSuccess(Login login);
    public void onError(String menssageError);
}
