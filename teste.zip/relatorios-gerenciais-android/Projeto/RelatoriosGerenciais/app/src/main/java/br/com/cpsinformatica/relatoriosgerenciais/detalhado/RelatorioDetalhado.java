package br.com.cpsinformatica.relatoriosgerenciais.detalhado;

import java.util.List;

import br.com.cpsinformatica.relatoriosgerenciais.totais.FooterRecorrencia;
import br.com.cpsinformatica.relatoriosgerenciais.totais.FooterTotalGeral;
import br.com.cpsinformatica.relatoriosgerenciais.totais.FormasPagamentoTotais;

/**
 * Created by rodrigo on 17/02/16.
 */
public class RelatorioDetalhado {

    private boolean status;
    private String mensagem;
    private CabecalhoDetalhado cabecalhoDetalhado;
    private List<FormasPagamentoDetalhado> formasPagamentosList;
    private List<ProdutosDetalhado> produtosDetalhadoList;
    private FooterTotalGeral footerTotalGeral;
    private FooterRecorrencia footerRecorrencia;

    public boolean isStatus() {
        return status;
    }

    public void setStatus(boolean status) {
        this.status = status;
    }

    public String getMensagem() {
        return mensagem;
    }

    public void setMensagem(String mensagem) {
        this.mensagem = mensagem;
    }

    public CabecalhoDetalhado getCabecalhoDetalhado() {
        return cabecalhoDetalhado;
    }

    public void setCabecalhoDetalhado(CabecalhoDetalhado cabecalhoDetalhado) {
        this.cabecalhoDetalhado = cabecalhoDetalhado;
    }

    public List<FormasPagamentoDetalhado> getFormasPagamentosList() {
        return formasPagamentosList;
    }

    public void setFormasPagamentosList(List<FormasPagamentoDetalhado> formasPagamentosList) {
        this.formasPagamentosList = formasPagamentosList;
    }

    public List<ProdutosDetalhado> getProdutosDetalhadoList() {
        return produtosDetalhadoList;
    }

    public void setProdutosDetalhadoList(List<ProdutosDetalhado> produtosDetalhadoList) {
        this.produtosDetalhadoList = produtosDetalhadoList;
    }

    public FooterTotalGeral getFooterTotalGeral() {
        return footerTotalGeral;
    }

    public void setFooterTotalGeral(FooterTotalGeral footerTotalGeral) {
        this.footerTotalGeral = footerTotalGeral;
    }

    public FooterRecorrencia getFooterRecorrencia() {
        return footerRecorrencia;
    }

    public void setFooterRecorrencia(FooterRecorrencia footerRecorrencia) {
        this.footerRecorrencia = footerRecorrencia;
    }
}
