package br.com.cpsinformatica.relatoriosgerenciais.enums;

/**
 * Created by rodrigo on 17/02/16.
 */
public enum ParseTransacoesEnum {

    STATUS("status"),
    MENSAGEM("mensagem"),
    CABECALHO("CABECALHO"),
    ESTABELECIMENTO("estabelecimento"),
    ENDERECO("endereco"),
    CIDADE("cidade"),
    POS("pos"),
    DATETIME("datetime"),
    FORMAS_PAGAMENTO("FORMA_PAGAMENTO"),
    NSU("nsu"),
    DATA("data"),
    HORA("hora"),
    FORMA_PAG("formaPag"),
    STATUS_TRANSACAO("statusTransacao"),
    VALOR("valor"),
    BANDEIRA("bandeira"),
    CODAUTORIZACAO("codAutorizacao");

    private String valor;

    ParseTransacoesEnum(String str){
        valor = str;
    }

    public String getText(){
        return valor;
    }
}
