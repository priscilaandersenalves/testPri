package br.com.cpsinformatica.relatoriosgerenciais.activitys;

import android.content.Intent;
import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.support.v7.widget.Toolbar;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.EditText;

import java.math.BigInteger;
import java.security.MessageDigest;
import java.security.NoSuchAlgorithmException;

import javax.crypto.KeyGenerator;
import javax.crypto.SecretKey;

import br.com.cpsinformatica.relatoriosgerenciais.R;
import br.com.cpsinformatica.relatoriosgerenciais.domains.DateTimeBusca;
import br.com.cpsinformatica.relatoriosgerenciais.domains.Logar;
import br.com.cpsinformatica.relatoriosgerenciais.domains.UsuarioLogado;
import br.com.cpsinformatica.relatoriosgerenciais.utils.CapturaDateTime;
import br.com.cpsinformatica.relatoriosgerenciais.utils.Mensagens;
import br.com.cpsinformatica.relatoriosgerenciais.utils.Preferences;

public class LoginActivity extends AppCompatActivity {

    private Logar logar;
    private Button buttonEntrar;
    private EditText inputLogin;
    private EditText inputSenha;
    private CheckBox checkBoxLembrar;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_login);
        Toolbar toolbar = (Toolbar) findViewById(R.id.toolbar);
        setSupportActionBar(toolbar);

        initElements();

        DateTimeBusca.setDateTimeHoje();

        logar = new Logar(LoginActivity.this);

        // Verifica se existe IP salvo
        if(Preferences.getIP(this).equals("")) {
            Preferences.salvaIP(this, getString(R.string.ip));
        }
        Preferences.salvaIP(this, getString(R.string.ip));

        // Limpa dateTime Personalizado se existir
        Preferences.limparDataHoraPersonalizada(this);

        // Verifica se usuario existe
        if(!Preferences.getUsuario(this).equals("")) {

            // Salva usuario na variavel Global
            UsuarioLogado.setUsuario(Preferences.getUsuario(this));

            // Abre activity principal
            logar.abreMainActivity();
        }

        buttonEntrar.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                /*
                String senhaCriptografada = encryptSHA(inputSenha.getText().toString());
                if(senhaCriptografada.equals("")) {
                    Mensagens.mensagemSnackLong(LoginActivity.this, "Erro na criptografia");
                    return;
                }
                */

                logar.setChecked(checkBoxLembrar.isChecked());
                logar.efetuarLogin(inputLogin.getText().toString(), inputSenha.getText().toString());
            }
        });
    }

    private String encryptSHA(String senha){

        String returnPassword ="";
        try {

            MessageDigest md = MessageDigest.getInstance("SHA-1");

            md.update( senha.getBytes() );
            BigInteger hash = new BigInteger( 1, md.digest() );
            returnPassword = hash.toString( 16 );

        } catch (NoSuchAlgorithmException e1) {
            System.out.println(e1.getMessage());
        }

        return returnPassword;
    }

    private void initElements(){
        checkBoxLembrar = (CheckBox) findViewById(R.id.checkBoxLembrar);
        buttonEntrar = (Button) findViewById(R.id.buttonEntrar);
        inputLogin = (EditText) findViewById(R.id.inputLogin);
        inputSenha = (EditText) findViewById(R.id.inputSenha);
    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        // Inflate the menu; this adds items to the action bar if it is present.
        getMenuInflater().inflate(R.menu.menu_login, menu);
        return true;
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        // Handle action bar item clicks here. The action bar will
        // automatically handle clicks on the Home/Up button, so long
        // as you specify a parent activity in AndroidManifest.xml.
        int id = item.getItemId();

        //noinspection SimplifiableIfStatement
        if (id == R.id.action_settings) {

            Intent intent = new Intent(this, ConfiguracoesActivity.class);
            startActivity(intent);

            return true;
        }
        return super.onOptionsItemSelected(item);
    }
}
