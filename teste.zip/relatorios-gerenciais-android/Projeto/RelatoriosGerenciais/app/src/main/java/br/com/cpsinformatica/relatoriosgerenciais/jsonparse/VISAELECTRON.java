
package br.com.cpsinformatica.relatoriosgerenciais.jsonparse;

import javax.annotation.Generated;
import com.google.gson.annotations.Expose;
import com.google.gson.annotations.SerializedName;

@Generated("org.jsonschema2pojo")
public class VISAELECTRON {

    @SerializedName("bandeira")
    @Expose
    private String bandeira;
    @SerializedName("nsu")
    @Expose
    private Integer nsu;
    @SerializedName("data")
    @Expose
    private String data;
    @SerializedName("hora")
    @Expose
    private String hora;
    @SerializedName("statusTransacao")
    @Expose
    private String statusTransacao;
    @SerializedName("valor")
    @Expose
    private String valor;

    /**
     * 
     * @return
     *     The bandeira
     */
    public String getBandeira() {
        return bandeira;
    }

    /**
     * 
     * @param bandeira
     *     The bandeira
     */
    public void setBandeira(String bandeira) {
        this.bandeira = bandeira;
    }

    /**
     * 
     * @return
     *     The nsu
     */
    public Integer getNsu() {
        return nsu;
    }

    /**
     * 
     * @param nsu
     *     The nsu
     */
    public void setNsu(Integer nsu) {
        this.nsu = nsu;
    }

    /**
     * 
     * @return
     *     The data
     */
    public String getData() {
        return data;
    }

    /**
     * 
     * @param data
     *     The data
     */
    public void setData(String data) {
        this.data = data;
    }

    /**
     * 
     * @return
     *     The hora
     */
    public String getHora() {
        return hora;
    }

    /**
     * 
     * @param hora
     *     The hora
     */
    public void setHora(String hora) {
        this.hora = hora;
    }

    /**
     * 
     * @return
     *     The statusTransacao
     */
    public String getStatusTransacao() {
        return statusTransacao;
    }

    /**
     * 
     * @param statusTransacao
     *     The statusTransacao
     */
    public void setStatusTransacao(String statusTransacao) {
        this.statusTransacao = statusTransacao;
    }

    /**
     * 
     * @return
     *     The valor
     */
    public String getValor() {
        return valor;
    }

    /**
     * 
     * @param valor
     *     The valor
     */
    public void setValor(String valor) {
        this.valor = valor;
    }

}
