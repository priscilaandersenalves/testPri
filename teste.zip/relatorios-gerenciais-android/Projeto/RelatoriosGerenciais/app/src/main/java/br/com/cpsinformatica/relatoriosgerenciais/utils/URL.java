package br.com.cpsinformatica.relatoriosgerenciais.utils;

/**
 * Created by rodrigo on 16/02/16.
 */
public class URL {

    public static String LOGIN = "http://%s/cpsinformatica/Login?login=%s&senha=%s";
    public static String REL_TOTAIS = "http://%s/cpsinformatica/RelTotais?dataIni=%s&horaIni=%s&dataFim=%s&horaFim=%s&tipoBaixaTecnica=9004&loja=%s&idUsuario=1";
    public static String REL_DETALHADO = "http://%s/cpsinformatica/RelDetalhado?dataIni=%s&horaIni=%s&dataFim=%s&horaFim=%s&tipoBaixaTecnica=9004&loja=%s&idUsuario=1";
    public static String REL_TRANSACOES = "http://%s/cpsinformatica/RelTransacao?dataIni=%s&horaIni=%s&dataFim=%s&horaFim=%s&tipoBaixaTecnica=9004&loja=%s&idUsuario=1";

}