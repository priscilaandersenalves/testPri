package br.com.cpsinformatica.relatoriosgerenciais.activitys;

import android.annotation.SuppressLint;
import android.app.Activity;
import android.app.DatePickerDialog;
import android.app.Dialog;
import android.app.TimePickerDialog;
import android.content.Intent;
import android.os.Bundle;
import android.support.v4.app.DialogFragment;
import android.support.v7.app.AppCompatActivity;
import android.support.v7.widget.Toolbar;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.view.inputmethod.EditorInfo;
import android.widget.Button;
import android.widget.DatePicker;
import android.widget.EditText;
import android.widget.TimePicker;

import java.text.DecimalFormat;
import java.util.Calendar;

import br.com.cpsinformatica.relatoriosgerenciais.R;
import br.com.cpsinformatica.relatoriosgerenciais.domains.DateTimeBusca;
import br.com.cpsinformatica.relatoriosgerenciais.utils.Mensagens;
import br.com.cpsinformatica.relatoriosgerenciais.utils.Preferences;

public class PersonalizarActivity extends AppCompatActivity {

    private EditText inputDataInicial, inputHoraInicial, inputDataFinal, inputHoraFinal;
    private Button buttonOk, buttonCancelar;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_personalizar);
        Toolbar toolbar = (Toolbar) findViewById(R.id.toolbar);
        setSupportActionBar(toolbar);

        getSupportActionBar().setDisplayHomeAsUpEnabled(true);
        getSupportActionBar().setDisplayShowHomeEnabled(true);

        Intent returnIntent = new Intent();
        returnIntent.putExtra("result", "OK");
        setResult(Activity.RESULT_OK, returnIntent);

        initElements();

        eventsComponents();

        setValues();
    }

    private void setValues(){
        String[] dateTime = Preferences.getDataHoraPersonalizada(this);
        if(!dateTime[0].equals("")){
            inputDataInicial.setText(dateTime[0]);
            inputHoraInicial.setText(dateTime[1]);
            inputDataFinal.setText(dateTime[2]);
            inputHoraFinal.setText(dateTime[3]);
        }
    }

    private void initElements(){
        inputDataInicial = (EditText) findViewById(R.id.inputDataInicial);
        inputHoraInicial = (EditText) findViewById(R.id.inputHoraInicial);
        inputDataFinal = (EditText) findViewById(R.id.inputDataFinal);
        inputHoraFinal = (EditText) findViewById(R.id.inputHoraFinal);

        buttonOk = (Button) findViewById(R.id.buttonOk);
        buttonCancelar = (Button) findViewById(R.id.buttonCancelar);

        inputDataInicial.setInputType(EditorInfo.TYPE_NULL);
        inputHoraInicial.setInputType(EditorInfo.TYPE_NULL);
        inputDataFinal.setInputType(EditorInfo.TYPE_NULL);
        inputHoraFinal.setInputType(EditorInfo.TYPE_NULL);
    }

    private void eventsComponents(){

        inputDataInicial.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                DialogFragment newFragment = new DatePickerFragment(inputDataInicial);
                newFragment.show(getSupportFragmentManager(), "datePicker");

            }
        });

        inputHoraInicial.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                DialogFragment newFragment = new TimerPickerFragment(inputHoraInicial);
                newFragment.show(getSupportFragmentManager(), "timerPicker");

            }
        });

        inputDataFinal.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                DialogFragment newFragment = new DatePickerFragment(inputDataFinal);
                newFragment.show(getSupportFragmentManager(), "datePicker");

            }
        });

        inputHoraFinal.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                DialogFragment newFragment = new TimerPickerFragment(inputHoraFinal);
                newFragment.show(getSupportFragmentManager(), "timerPicker");

            }
        });

        buttonOk.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                if(inputDataInicial.getText().toString().equals("") || inputHoraInicial.getText().toString().equals("") ||
                        inputDataFinal.getText().toString().equals("") || inputHoraFinal.getText().toString().equals("")){

                    Mensagens.mensagemSnackLong(PersonalizarActivity.this, "PREENCHA TODOS OS CAMPOS");
                    return;
                }

                DateTimeBusca.setDateTimePersonalizado(inputDataInicial.getText().toString(),
                        inputHoraInicial.getText().toString(), inputDataFinal.getText().toString(),
                        inputHoraFinal.getText().toString());

                Preferences.savarDataHoraPersonalizada(PersonalizarActivity.this, inputDataInicial.getText().toString(),
                        inputHoraInicial.getText().toString(), inputDataFinal.getText().toString(),
                        inputHoraFinal.getText().toString());

                finish();
            }
        });

        buttonCancelar.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                finish();
            }
        });
    }

    @SuppressLint("ValidFragment")
    public static class DatePickerFragment extends DialogFragment
            implements DatePickerDialog.OnDateSetListener {

        private EditText input;

        public DatePickerFragment(EditText input) {
            this.input = input;
        }

        @Override
        public Dialog onCreateDialog(Bundle savedInstanceState) {

            // Use the current date as the default date in the picker
            final Calendar c = Calendar.getInstance();
            int year = c.get(Calendar.YEAR);
            int month = c.get(Calendar.MONTH);
            int day = c.get(Calendar.DAY_OF_MONTH);

            // Create a new instance of DatePickerDialog and return it
            return new DatePickerDialog(getActivity(), this, year, month, day);

        }

        public void onDateSet(DatePicker view, int year, int month, int day) {
            input.setText(String.valueOf(year).toString() + "-" + formatDateTwoNumber(month+1) + "-" + formatDateTwoNumber(day));
        }

        private static String formatDateTwoNumber(int val){
            DecimalFormat formatter = new DecimalFormat("00");
            return formatter.format(val);
        }
    }

    @SuppressLint("ValidFragment")
    public static class TimerPickerFragment extends DialogFragment
            implements TimePickerDialog.OnTimeSetListener {

        private EditText input;

        public TimerPickerFragment(EditText input) {
            this.input = input;
        }

        @Override
        public Dialog onCreateDialog(Bundle savedInstanceState) {

            // Use the current date as the default date in the picker
            final Calendar c = Calendar.getInstance();
            int hourOfDay = c.get(Calendar.HOUR_OF_DAY);
            int minute = c.get(Calendar.MINUTE);

            // Create a new instance of DatePickerDialog and return it
            return new TimePickerDialog(getActivity(), (TimePickerDialog.OnTimeSetListener) this, hourOfDay, minute, true);

        }

        public void onTimeSet(TimePicker view, int hourOfDay, int minute) {
            input.setText(formatDateTwoNumber(hourOfDay).toString() + ":" + formatDateTwoNumber(minute));
        }

        private static String formatDateTwoNumber(int val){
            DecimalFormat formatter = new DecimalFormat("00");
            return formatter.format(val);
        }
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {

        onBackPressed();

        return super.onOptionsItemSelected(item);
    }
}
