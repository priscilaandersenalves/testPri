
package br.com.cpsinformatica.relatoriosgerenciais.jsonparse;

import java.util.ArrayList;
import java.util.List;
import javax.annotation.Generated;
import javax.validation.Valid;
import com.google.gson.annotations.Expose;
import com.google.gson.annotations.SerializedName;

@Generated("org.jsonschema2pojo")
public class DEBITO {

    @SerializedName("TOTAL VISA ELECTRON")
    @Expose
    @Valid
    private List<br.com.cpsinformatica.relatoriosgerenciais.jsonparse.TOTALVISAELECTRON> TOTALVISAELECTRON = new ArrayList<br.com.cpsinformatica.relatoriosgerenciais.jsonparse.TOTALVISAELECTRON>();
    @SerializedName("VISA ELECTRON")
    @Expose
    @Valid
    private List<br.com.cpsinformatica.relatoriosgerenciais.jsonparse.VISAELECTRON> VISAELECTRON = new ArrayList<br.com.cpsinformatica.relatoriosgerenciais.jsonparse.VISAELECTRON>();

    /**
     * 
     * @return
     *     The TOTALVISAELECTRON
     */
    public List<br.com.cpsinformatica.relatoriosgerenciais.jsonparse.TOTALVISAELECTRON> getTOTALVISAELECTRON() {
        return TOTALVISAELECTRON;
    }

    /**
     * 
     * @param TOTALVISAELECTRON
     *     The TOTAL VISA ELECTRON
     */
    public void setTOTALVISAELECTRON(List<br.com.cpsinformatica.relatoriosgerenciais.jsonparse.TOTALVISAELECTRON> TOTALVISAELECTRON) {
        this.TOTALVISAELECTRON = TOTALVISAELECTRON;
    }

    /**
     * 
     * @return
     *     The VISAELECTRON
     */
    public List<br.com.cpsinformatica.relatoriosgerenciais.jsonparse.VISAELECTRON> getVISAELECTRON() {
        return VISAELECTRON;
    }

    /**
     * 
     * @param VISAELECTRON
     *     The VISA ELECTRON
     */
    public void setVISAELECTRON(List<br.com.cpsinformatica.relatoriosgerenciais.jsonparse.VISAELECTRON> VISAELECTRON) {
        this.VISAELECTRON = VISAELECTRON;
    }

}
