
package br.com.cpsinformatica.relatoriosgerenciais.jsonparse;

import javax.annotation.Generated;
import javax.validation.Valid;
import com.google.gson.annotations.Expose;
import com.google.gson.annotations.SerializedName;

@Generated("org.jsonschema2pojo")
public class GsonParse {

    @SerializedName("status")
    @Expose
    private Boolean status;
    @SerializedName("mensagem")
    @Expose
    private String mensagem;
    @SerializedName("CABECALHO")
    @Expose
    @Valid
    private br.com.cpsinformatica.relatoriosgerenciais.jsonparse.CABECALHO CABECALHO;
    @SerializedName("FORMAS_PAGAMENTO")
    @Expose
    @Valid
    private br.com.cpsinformatica.relatoriosgerenciais.jsonparse.FORMASPAGAMENTO FORMASPAGAMENTO;
    @SerializedName("TOTAL_GERAL")
    @Expose
    @Valid
    private br.com.cpsinformatica.relatoriosgerenciais.jsonparse.TOTALGERAL TOTALGERAL;

    /**
     * 
     * @return
     *     The status
     */
    public Boolean getStatus() {
        return status;
    }

    /**
     * 
     * @param status
     *     The status
     */
    public void setStatus(Boolean status) {
        this.status = status;
    }

    /**
     * 
     * @return
     *     The mensagem
     */
    public String getMensagem() {
        return mensagem;
    }

    /**
     * 
     * @param mensagem
     *     The mensagem
     */
    public void setMensagem(String mensagem) {
        this.mensagem = mensagem;
    }

    /**
     * 
     * @return
     *     The CABECALHO
     */
    public br.com.cpsinformatica.relatoriosgerenciais.jsonparse.CABECALHO getCABECALHO() {
        return CABECALHO;
    }

    /**
     * 
     * @param CABECALHO
     *     The CABECALHO
     */
    public void setCABECALHO(br.com.cpsinformatica.relatoriosgerenciais.jsonparse.CABECALHO CABECALHO) {
        this.CABECALHO = CABECALHO;
    }

    /**
     * 
     * @return
     *     The FORMASPAGAMENTO
     */
    public br.com.cpsinformatica.relatoriosgerenciais.jsonparse.FORMASPAGAMENTO getFORMASPAGAMENTO() {
        return FORMASPAGAMENTO;
    }

    /**
     * 
     * @param FORMASPAGAMENTO
     *     The FORMAS_PAGAMENTO
     */
    public void setFORMASPAGAMENTO(br.com.cpsinformatica.relatoriosgerenciais.jsonparse.FORMASPAGAMENTO FORMASPAGAMENTO) {
        this.FORMASPAGAMENTO = FORMASPAGAMENTO;
    }

    /**
     * 
     * @return
     *     The TOTALGERAL
     */
    public br.com.cpsinformatica.relatoriosgerenciais.jsonparse.TOTALGERAL getTOTALGERAL() {
        return TOTALGERAL;
    }

    /**
     * 
     * @param TOTALGERAL
     *     The TOTAL_GERAL
     */
    public void setTOTALGERAL(br.com.cpsinformatica.relatoriosgerenciais.jsonparse.TOTALGERAL TOTALGERAL) {
        this.TOTALGERAL = TOTALGERAL;
    }

}
