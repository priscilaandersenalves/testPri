package br.com.cpsinformatica.relatoriosgerenciais.enums;

/**
 * Created by rodrigo on 18/02/16.
 */
public enum MensagemErroEnum {

    TEMPO_EXCEDIDO("TEMPO EXCEDIDO"),
    SEM_CONEXAO("SEM CONEXÃO"),
    NAO_EXISTE_PAGAMENTOS("NÃO EXISTE PAGAMENTOS NESSE PIRÍODO"),
    TENTAR("TENTAR"),
    HOST("ENDEREÇO INVÁLIDO");

    private String valor;

    MensagemErroEnum(String str){
        valor = str;
    }

    public String getText(){
        return valor;
    }
}
