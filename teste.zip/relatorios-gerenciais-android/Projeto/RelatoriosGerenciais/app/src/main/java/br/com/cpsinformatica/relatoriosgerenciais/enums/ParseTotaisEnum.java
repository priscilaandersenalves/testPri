package br.com.cpsinformatica.relatoriosgerenciais.enums;

/**
 * Created by rodrigo on 17/02/16.
 */
public enum ParseTotaisEnum {

    STATUS("status"),
    MENSAGEM("mensagem"),
    CABECALHO("CABECALHO"),
    ESTABELECIMENTO("estabelecimento"),
    ENDERECO("endereco"),
    CIDADE("cidade"),
    POS("pos"),
    DATETIME("datetime"),
    FORMAS_PAGAMENTO("FORMAS_PAGAMENTO"),
    BANDEIRA("bandeira"),
    QUANTIDADE("qtdePag"),
    VALOR("valorTotPag"),
    TOTAL_GERAL_UPP("TOTAL_GERAL"),
    QTDE_CANCEL("qtdeCancel"),
    TOTAL_CANCEL("totalCancel"),
    QTDE_GERAL("qtdeGeral"),
    TOTAL_GERAL("totalGeral");

    private String valor;

    ParseTotaisEnum(String str){
        valor = str;
    }

    public String getText(){
        return valor;
    }
}
