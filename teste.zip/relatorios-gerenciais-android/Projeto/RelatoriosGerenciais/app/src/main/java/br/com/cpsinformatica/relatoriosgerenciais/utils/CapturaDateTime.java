package br.com.cpsinformatica.relatoriosgerenciais.utils;

import java.text.DecimalFormat;
import java.util.Calendar;

import br.com.cpsinformatica.relatoriosgerenciais.domains.DateTimeBusca;

/**
 * Created by rodrigo on 18/02/16.
 */
public class CapturaDateTime {

    private static Calendar c;

    public static String getDateInicial(){

        Calendar calendar = Calendar.getInstance();
        calendar.add(Calendar.MONTH, +1);

        int dia = calendar.get(Calendar.DAY_OF_MONTH);
        int mes = calendar.get(Calendar.MONTH)+1;
        int ano = calendar.get(Calendar.YEAR);

        return ano +"-"+ formatDateTwoNumber(mes) +"-"+ formatDateTwoNumber(dia);
    }

    public static String getDateFinal(){

        Calendar calendar = Calendar.getInstance();
        calendar.add(Calendar.MONTH, +1);

        int dia = calendar.get(Calendar.DAY_OF_MONTH);
        int mes = calendar.get(Calendar.MONTH);
        int ano = calendar.get(Calendar.YEAR);

        return ano +"-"+ formatDateTwoNumber(mes) +"-"+ formatDateTwoNumber(dia);
    }

    public static String getDataHoje(){

        Calendar calendar = Calendar.getInstance();
        calendar.add(Calendar.MONTH, +1);

        int dia = calendar.get(Calendar.DAY_OF_MONTH);
        int mes = calendar.get(Calendar.MONTH);
        int ano = calendar.get(Calendar.YEAR);

        return ano +"-"+ formatDateTwoNumber(mes) +"-"+ formatDateTwoNumber(dia);
    }

    public static String getHoraAtual(){

        Calendar calendar = Calendar.getInstance();
        int hora = calendar.get(Calendar.HOUR_OF_DAY);
        int minuto = calendar.get(Calendar.MINUTE);

        return formatDateTwoNumber(hora) +":"+ formatDateTwoNumber(minuto);
    }

    public static String getDataOntem(){

        Calendar calendar = Calendar.getInstance();
        calendar.add(Calendar.DAY_OF_MONTH, -1);
        calendar.add(Calendar.MONTH, +1);

        int dia = calendar.get(Calendar.DAY_OF_MONTH);
        int mes = calendar.get(Calendar.MONTH);
        int ano = calendar.get(Calendar.YEAR);

        return ano +"-"+ formatDateTwoNumber(mes) +"-"+ formatDateTwoNumber(dia);
    }

    public static String getDataDias(int dias){

        Calendar calendar = Calendar.getInstance();
        calendar.add(Calendar.DAY_OF_MONTH, -dias);
        calendar.add(Calendar.MONTH, +1);

        int dia = calendar.get(Calendar.DAY_OF_MONTH);
        int mes = calendar.get(Calendar.MONTH);
        int ano = calendar.get(Calendar.YEAR);

        return ano +"-"+ formatDateTwoNumber(mes) +"-"+ formatDateTwoNumber(dia);
    }

    public static String getDataMes(){

        Calendar calendar = Calendar.getInstance();
        calendar.add(Calendar.MONTH, +1);

        int mes = calendar.get(Calendar.MONTH);
        int ano = calendar.get(Calendar.YEAR);

        return ano +"-"+ formatDateTwoNumber(mes) +"-"+ formatDateTwoNumber(1);
    }

    private static String formatDateTwoNumber(int val){
        DecimalFormat formatter = new DecimalFormat("00");
        return formatter.format(val);
    }
}
