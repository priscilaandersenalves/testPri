package br.com.cpsinformatica.relatoriosgerenciais.domains;

/**
 * Created by rodrigo on 22/02/16.
 */
public class Login {

    private boolean status;
    private String mensagem;

    public boolean isStatus() {
        return status;
    }

    public void setStatus(boolean status) {
        this.status = status;
    }

    public String getMensagem() {
        return mensagem;
    }

    public void setMensagem(String mensagem) {
        this.mensagem = mensagem;
    }
}
