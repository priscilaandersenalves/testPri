package br.com.cpsinformatica.relatoriosgerenciais.totais;

/**
 * Created by rodrigo on 18/02/16.
 */
public class FooterTotalGeral {

    private int qtdCancel;
    private String totalCancel;
    private int qtdGeral;
    private String totalGeral;

    public int getQtdCancel() {
        return qtdCancel;
    }

    public void setQtdCancel(int qtdCancel) {
        this.qtdCancel = qtdCancel;
    }

    public String getTotalCancel() {
        return totalCancel;
    }

    public void setTotalCancel(String totalCancel) {
        this.totalCancel = totalCancel;
    }

    public int getQtdGeral() {
        return qtdGeral;
    }

    public void setQtdGeral(int qtdGeral) {
        this.qtdGeral = qtdGeral;
    }

    public String getTotalGeral() {
        return totalGeral;
    }

    public void setTotalGeral(String totalGeral) {
        this.totalGeral = totalGeral;
    }
}
