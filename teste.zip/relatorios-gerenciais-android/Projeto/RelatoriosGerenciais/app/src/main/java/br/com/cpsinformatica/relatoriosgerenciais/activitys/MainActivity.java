package br.com.cpsinformatica.relatoriosgerenciais.activitys;

import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.support.design.widget.NavigationView;
import android.support.design.widget.TabLayout;
import android.support.v4.app.Fragment;
import android.support.v4.app.FragmentManager;
import android.support.v4.app.FragmentPagerAdapter;
import android.support.v4.view.GravityCompat;
import android.support.v4.view.ViewPager;
import android.support.v4.widget.DrawerLayout;
import android.support.v7.app.AppCompatActivity;
import android.support.v7.widget.Toolbar;
import android.view.Gravity;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.widget.ImageButton;

import br.com.cpsinformatica.relatoriosgerenciais.Networking.CarregaRelatorioTotais;
import br.com.cpsinformatica.relatoriosgerenciais.R;
import br.com.cpsinformatica.relatoriosgerenciais.actionbar.ActionbarCustom;
import br.com.cpsinformatica.relatoriosgerenciais.domains.DateTimeBusca;
import br.com.cpsinformatica.relatoriosgerenciais.fragments.FragmentDetalhes;
import br.com.cpsinformatica.relatoriosgerenciais.fragments.FragmentTotais;
import br.com.cpsinformatica.relatoriosgerenciais.fragments.FragmentTransacoes;
import br.com.cpsinformatica.relatoriosgerenciais.utils.Preferences;

public class MainActivity extends AppCompatActivity
        implements NavigationView.OnNavigationItemSelectedListener {

    /**
     * The {@link android.support.v4.view.PagerAdapter} that will provide
     * br.com.cpsinformatica.testerelatorios.fragments for each of the sections. We use a
     * {@link FragmentPagerAdapter} derivative, which will keep every
     * loaded fragment in memory. If this becomes too memory intensive, it
     * may be best to switch to a
     * {@link android.support.v4.app.FragmentStatePagerAdapter}.
     */
    private SectionsPagerAdapter mSectionsPagerAdapter;

    /**
     * The {@link ViewPager} that will host the section contents.
     */
    private ViewPager mViewPager;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        Toolbar toolbar = (Toolbar) findViewById(R.id.toolbar);
        setSupportActionBar(toolbar);

        final DrawerLayout drawer = (DrawerLayout) findViewById(R.id.drawer_layout);

        /*
        FloatingActionButton fab = (FloatingActionButton) findViewById(R.id.fab);
        fab.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                drawer.openDrawer(Gravity.LEFT);
            }
        });
        */

        NavigationView navigationView = (NavigationView) findViewById(R.id.nav_view);
        navigationView.setNavigationItemSelectedListener(this);

        ImageButton imageButtonMenu = (ImageButton) findViewById(R.id.imageButtonMenu);
        imageButtonMenu.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                drawer.openDrawer(Gravity.LEFT);
            }
        });

        /*
        ActionBarDrawerToggle toggle = new ActionBarDrawerToggle(
            this, drawer, toolbar, R.string.navigation_drawer_open, R.string.navigation_drawer_close);
        drawer.setDrawerListener(toggle);
        toggle.syncState();
        */

        ActionbarCustom.addCustomActionbar(this);

        // Create the adapter that will return a fragment for each of the three
        // primary sections of the activity.
        mSectionsPagerAdapter = new SectionsPagerAdapter(getSupportFragmentManager());

        // Set up the ViewPager with the sections adapter.
        mViewPager = (ViewPager) findViewById(R.id.container);
        mViewPager.setAdapter(mSectionsPagerAdapter);

        TabLayout tabLayout = (TabLayout) findViewById(R.id.tabs);
        tabLayout.setupWithViewPager(mViewPager);
    }

    @Override
    public void onBackPressed() {
        DrawerLayout drawer = (DrawerLayout) findViewById(R.id.drawer_layout);
        if (drawer.isDrawerOpen(GravityCompat.START)) {
            drawer.closeDrawer(GravityCompat.START);
        } else {
            super.onBackPressed();
        }
    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        // Inflate the menu; this adds items to the action bar if it is present.
        getMenuInflater().inflate(R.menu.menu_main, menu);
        return true;
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        // Handle action bar item clicks here. The action bar will
        // automatically handle clicks on the Home/Up button, so long
        // as you specify a parent activity in AndroidManifest.xml.
        int id = item.getItemId();

        //noinspection SimplifiableIfStatement
        if (id == R.id.action_settings) {

            Intent intent = new Intent(this, ConfiguracoesActivity.class);
            startActivity(intent);

            return true;
        }
        if (id == R.id.actionLogout) {

            Preferences.removeUsuario(this);

            Intent intent = new Intent(this, LoginActivity.class);
            startActivity(intent);

            this.finish();

            return true;
        }

        return super.onOptionsItemSelected(item);
    }

    /**
     * A {@link FragmentPagerAdapter} that returns a fragment corresponding to
     * one of the sections/tabs/pages.
     */
    public class SectionsPagerAdapter extends FragmentPagerAdapter {

        public SectionsPagerAdapter(FragmentManager fm) {
            super(fm);
        }

        @Override
        public Fragment getItem(int position) {

            // getItem is called to instantiate the fragment for the given page.
            // Return a PlaceholderFragment (defined as a static inner class below).
            switch (position){
                case 0:
                    return FragmentTotais.newInstance(position + 1);
                case 1:
                    return FragmentDetalhes.newInstance(position + 1);
                case 2:
                    return FragmentTransacoes.newInstance(position + 1);
                default:
                    return null;
            }
        }

        @Override
        public int getCount() {
            // Show 2 total pages.
            return 3;
        }

        @Override
        public CharSequence getPageTitle(int position) {
            switch (position) {
                case 0:
                    return getString(R.string.title_tab_totais);
                case 1:
                    return getString(R.string.title_tab_detalhes);
                case 2:
                    return getString(R.string.title_tab_transacoes);
                default:
                    return "";
            }
        }
    }

    @SuppressWarnings("StatementWithEmptyBody")
    @Override
    public boolean onNavigationItemSelected(MenuItem item) {
        // Handle navigation view item clicks here.
        int id = item.getItemId();

        if(CarregaRelatorioTotais.getSnackbar() != null)
            CarregaRelatorioTotais.snackbarDismiss();

        if (id == R.id.item_listar_hoje) {

            DateTimeBusca.setDateTimeHoje();

        } else if (id == R.id.item_listar_ontem) {

            DateTimeBusca.setDateTimeOtem();

        } else if (id == R.id.item_listar_7dias) {

            DateTimeBusca.setDateTime7Dias();

        } else if (id == R.id.item_listar_15dias) {

            DateTimeBusca.setDateTime15Dias();

        } else if (id == R.id.item_listar_esse_mes) {

            DateTimeBusca.setDateTimeEsseMes();

        } else if (id == R.id.item_listar_personalizado) {

            Intent intent = new Intent(MainActivity.this, PersonalizarActivity.class);
            startActivityForResult(intent, 15018);

        }

        recarregaRelatorio();

        return true;
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {

        if (requestCode == 15018) {
            // Make sure the request was successful
            if (resultCode == Activity.RESULT_OK) {
                recarregaRelatorio();
            }
        }
    }

    /**
     * Faz uma nova requisição da lista após
     * selecionar um item do Menu Lateral
     */
    private void recarregaRelatorio(){

        // Fecha menu lateral
        DrawerLayout drawer = (DrawerLayout) findViewById(R.id.drawer_layout);
        drawer.closeDrawer(GravityCompat.START);

        // Atualiza fragmento
        int currentItem = mViewPager.getCurrentItem();
        mViewPager.setAdapter(null);
        mViewPager.setAdapter(mSectionsPagerAdapter);
        mViewPager.setCurrentItem(currentItem);
    }
}