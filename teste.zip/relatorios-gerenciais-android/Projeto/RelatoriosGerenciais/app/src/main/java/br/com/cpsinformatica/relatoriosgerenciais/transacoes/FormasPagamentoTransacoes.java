package br.com.cpsinformatica.relatoriosgerenciais.transacoes;

import java.util.List;

/**
 * Created by rodrigo on 16/02/16.
 */
public class FormasPagamentoTransacoes {

    private String formaPagamento;
    private List<DetalheTransacoes> detalhePagamentoList;

    public String getFormaPagamento() {
        return formaPagamento;
    }

    public void setFormaPagamento(String formaPagamento) {
        this.formaPagamento = formaPagamento;
    }

    public List<DetalheTransacoes> getDetalhePagamentoList() {
        return detalhePagamentoList;
    }

    public void setDetalhePagamentoList(List<DetalheTransacoes> detalhePagamentoList) {
        this.detalhePagamentoList = detalhePagamentoList;
    }
}
